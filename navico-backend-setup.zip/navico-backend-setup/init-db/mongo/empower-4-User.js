db = db.getSiblingDB(_getEnv("CV_EMPOWER_MONGO_DB"));
db.createCollection("User");

db.User.insertMany([
    {
        _id: ObjectId("640a37364f9d130626264fd3"),
        isDeleted: false,
        location: "US",
        devices: [
            {
                type: "mobile",
                status: "active",
                _id: {
                    $oid: "640a37364f9d130626264fd4",
                },
                createdDate: {
                    $date: "2023-08-14T16:56:11.618Z",
                },
                updatedDate: {
                    $date: "2023-08-14T16:56:11.618Z",
                },
            },
        ],
        settings: [],
        b2cId: "b6aaa7b9-36a4-4a68-b316-9827936d01f0",
        profile: {
            firstName: "Rahul",
            lastName: "M",
        },
        groups: [
            {
                $oid: "648a3799ac2946357b35c0cd",
            },
        ],
    },
]);
