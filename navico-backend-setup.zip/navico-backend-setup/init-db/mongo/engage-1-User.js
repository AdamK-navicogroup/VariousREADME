db = db.getSiblingDB(_getEnv("CV_ENGAGE_MONGO_DB"));
db.createCollection("user");

db.user.insertMany([
    {
        _id: ObjectId("63f78bbb6efd6d2559427a7a"),
        brandName: "SR",
        userId: "63c7020923d181a842090fff",
        Onboarding: {
            averageDuration: "Couple of hours",
            boatingActivities: "Freshwater Fishing",
            boatingExperience:
                "I've rented boats,I've been in a boat club,This is my first boat,I've owned other types of boats,I've owned many boats",
            boatingSeason: "Summer",
            boatingSkill: "Expert",
            boatingStorage: "In Water (Marina)",
            boatingYearStarted: "2023",
            commonBodiesOfWater: "Bay",
            frequencyOfUse: "1x Week",
        },
        _partitionKey: "63c7020923d181a842090fff",
        appLastAccessDateTime: new Date("2023-04-12T21:03:26.934Z"),
        appLastLoginTime: new Date("2023-04-10T18:05:56.500Z"),
        azureObjectId: "d2a817ce-95af-47e6-8019-88d8d0ccd916",
        boRelationship: "hasRegisteredBoat",
        email: "eeuropadev22+rahul1@gmail.com",
        hin: {
            current: "SERV0907DEVA22",
        },
        monitoring: true,
        monitoringHardwareType: "Empower",
        release: {
            currentVersion: "2.0.1-dev",
            releaseNumber: 1,
        },
    },
    {
        _id: ObjectId("63371cb7a6d7ee2cc8bdbf4d"),
        brandName: "SR",
        userId: "63371caf00f9a7410bcfb897",
        Onboarding: {
            averageDuration: "Half day",
            boatingActivities:
                "Day Cruising,Overnighting,Freshwater Fishing,Offshore Fishing,Water Sports,Swimming,Waterfront Dining,Entertaining at the Dock,Beaching,Snorkeling & Diving,Island Hopping",
            boatingExperience:
                "I grew up on the water,I've rented boats,I've been in a boat club,This is my first boat,I've owned other types of boats,I've owned many boats",
            boatingSeason: "Summer,Fall",
            boatingSkill: "Novice",
            boatingStorage: "In Water (Private Dock)",
            boatingYearStarted: "2019",
            commonBodiesOfWater: "Small Lake or Reservoir",
            frequencyOfUse: "3-4x Season",
        },
        _partitionKey: "63371caf00f9a7410bcfb897",
        appLastAccessDateTime: new Date(1674485330158),
        appLastLoginTime: new Date(1674485328319),
        azureObjectId: "b6aaa7b9-36a4-4a68-b316-9827936d01f0",
        boRelationship: "hasRegisteredBoat",
        email: "europadev22+rahul1@gmail.com",
        hin: {
            current: "test-europa-boat",
        },
        monitoring: true,
        monitoringHardwareType: "Empower",
        release: {
            currentVersion: "2.0.0-dev",
            releaseNumber: 1,
        },
    },
]);
