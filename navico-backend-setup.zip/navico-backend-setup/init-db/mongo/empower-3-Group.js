db = db.getSiblingDB(_getEnv("CV_EMPOWER_MONGO_DB"));
db.createCollection("Group");

db.Group.insertMany([
  {
    _id: ObjectId("648a3799ac2946357b35c0cd"),
    name: "Group",
    oem: "6345871eea4611f5d78c140d",
    factory: "6402203667efd5421420600a",
    anchors: [],
    permissions: ["empower:user.invite"],
  },
]);
