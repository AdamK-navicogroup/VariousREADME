db = db.getSiblingDB("user");
db.createCollection("Group");

db.Group.insertMany([
    {
        _id: ObjectId("648a3799ac2946357b35c0cd"),
        name: "Group",
        oem: "6345871eea4611f5d78c140d",
        factory: "6402203667efd5421420600a",
        anchors: [],
        permissions: [
            "empower:workflow.check",
            "empower:workflow.update",
            "empower:workflow.delete",
            "empower:workflow.boat.control",
            "empower:boat.view",
            "empower:boat.control",
            "empower:boat.delete",
            "empower:factory.create",
            "empower:factory.update",
            "empower:factory.delete",
            "empower:factory.view",
            "empower:oem.create",
            "empower:oem.update",
            "empower:oem.delete",
            "empower:oem.view",
            "empower:group.update",
            "empower:group.delete",
            "empower:user.view",
            "empower:user.update",
            "empower:user.delete",
        ],
    },
]);
