db = db.getSiblingDB("iot");
db.createCollection("Bridge");

db.Bridge.insertMany([
    {
        _id: ObjectId("63122e5ad6fee2cef850eb6f"),
        name: "Europa",
        metadata: {
            "europa:deviceId": "rahul-sim-sandbox",
            "europa:applicationId": "5c42fb38-0a40-4753-8399-522ae7d649a0",
        },
        platform: "europa",
        isDeleted: false,
        location: "US",
        connectionStatus: {
            status: "disconnected",
            lastConnectedDate: ISODate("2022-09-07T19:48:16.181Z"),
        },
        __v: 0,
        entity: ObjectId("62b7d258bb0e46fcb511f076"),
    },
    {
        _id: ObjectId("62b7d24a85fb1c7df345ef8c"),
        name: "Nauticon",
        metadata: {
            "nauticon:networkId": "610d50dfce569f8fa2af699f",
        },
        platform: "nauticon",
        isDeleted: false,
        location: "US",
        connectionStatus: {
            status: "disconnected",
            lastConnectedDate: ISODate("2022-09-07T19:48:16.181Z"),
        },
        __v: 0,
        entity: ObjectId("62b7d258bb0e46fcb511f077"),
    },
]);
