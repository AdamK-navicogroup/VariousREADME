db = db.getSiblingDB(_getEnv("CV_MONGO_DEVICE_DB"));
db.createCollection("networks");

db.networks.insertMany([
  {
    _id: ObjectId("610d50dfce569f8fa2af699f"),
    valid: true,
    creator: "SYSTEM",
    isLinkedToUser: true,
    boatOwnerSubscription: {
      subscriptionEndTime: 0,
      subscriptionStartTime: 0,
      subscriptionPaidByUserUuid: null,
    },
    verified: true,
    boatOutsideOfGeofence: true,
    name: "Network DEMO11636-8691HB",
    description: "New network for monitoring my boat.",
    createdAt: new Date(1628262623452),
    updatedAt: new Date(1659978913547),
    __v: 0,
    lastReportedDataTimeStamp: 1659978912,
    kitTypeId: ObjectId("610d51d97497e1e9d4528cbe"),
    boatData: {
      hin: "SERV11636H821",
      year: "Unknown",
      model: "Unknown",
      name: "Unknown",
      uuid: "104d68c0-6b3c-4572-89b1-036530c778ef",
      account: "Joseph, Sara",
      isInstallCompleted: true,
      valid: true,
      isFactoryInstalled: true,
      lastAccess: "2022-02-10T17:10:01.880Z",
      lastSyncTime: "2022-02-10T17:10:01.880Z",
    },
  },
]);
