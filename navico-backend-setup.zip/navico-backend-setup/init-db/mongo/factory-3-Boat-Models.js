db = db.getSiblingDB("factory");
db.createCollection("BoatModel");

db.BoatModel.insertMany([
    {
        _id: ObjectId("6407ae8407342a9896285c9c"),
        year: "2024",
        model: "Queen Cruiser",
        oem: ObjectId("6345871eea4611f5d78c140d"),
        isDeleted: false,
    },
]);
