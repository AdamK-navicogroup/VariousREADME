db = db.getSiblingDB(_getEnv("CV_ENGAGE_MONGO_DB"));
db.createCollection("trips");
