db = db.getSiblingDB("factory");
db.createCollection("Oem");

db.Oem.insertMany([
    {
        _id: ObjectId("6345871eea4611f5d78c140d"),
        name: "Bob's Boats",
        shortName: "bboats",
        brandCode: "SR",
        applicationId: "afb434ec-dd1c-4096-9c33-54c0e06d5f69",
        address: {
            streetLine1: "123 Main St",
            locality: "Pembrook Pines",
            region: "FL",
            postalCode: "92838",
            country: "US",
        },
        brand: {
            website: "http://example.com",
            logos: [
                {
                    url: "http://example.com",
                    metadata: {
                        resolution: "64x64",
                    },
                },
            ],
        },
        contacts: [
            {
                type: "support",
                name: "Bing Bong",
                email: "bingbong@example.com",
                phones: [
                    {
                        type: "office",
                        number: "+1 (828) 282-2818",
                        extension: "513",
                    },
                ],
            },
        ],
        crmConfig: {
            _id: ObjectId("63458756efd9c5788066b35b"),
        },
        isDeleted: false,
    },
]);
