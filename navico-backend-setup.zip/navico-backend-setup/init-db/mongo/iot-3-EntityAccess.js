db = db.getSiblingDB("iot");
db.createCollection("EntityAccess");

db.EntityAccess.insertMany([
    {
        _id: ObjectId("640a37b04f9d130626264fd6"),
        entity: ObjectId("62b7d258bb0e46fcb511f076"),
        user: ObjectId("640a37364f9d130626264fd3"),
        type: "primaryOwner",
        location: "US",
        isDeleted: false,
        __v: { $numberInt: "0" },
    },
]);
