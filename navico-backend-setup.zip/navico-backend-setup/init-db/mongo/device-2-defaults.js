db = db.getSiblingDB(_getEnv("CV_MONGO_DEVICE_DB"));

db.createCollection("batterydefaults");
db.batterydefaults.insertMany([
  {
    _id: ObjectId("5db06bda3c11f1d7f40a2475"),
    settings: [
      {
        settingName: "deviceTypeId",
        defaultValue: "5908bf9f12ca6430e2000002",
        units: null,
      },
      { settingName: "installDate", defaultValue: null, units: null },
      { settingName: "zoneLocation", defaultValue: null, units: null },
      { settingName: "miwiConfigId", defaultValue: null, units: null },
      {
        settingName: "lowSocThreshold",
        defaultValue: 40.0,
        units: "%",
      },
      {
        settingName: "highSocThreshold",
        defaultValue: 100.0,
        units: "%",
      },
      {
        settingName: "alertOnLowSoc",
        defaultValue: false,
        units: "03b2cc60-7890-4c2b-b498-dd3cda01370c",
      },
      {
        settingName: "alertOnHighSoc",
        defaultValue: false,
        units: "04b2cc60-7890-4c2b-b498-dd3cda01370c",
      },
      {
        settingName: "maxVoltage",
        defaultValue: 14.5,
        units: "V",
      },
      {
        settingName: "minVoltage",
        defaultValue: 11.9,
        units: "V",
      },
      {
        settingName: "maxChargeCurrent",
        defaultValue: 20.0,
        units: "A",
      },
      {
        settingName: "maxDischargeCurrent",
        defaultValue: 1200.0,
        units: "A",
      },
      {
        settingName: "alertOnMaxVoltage",
        defaultValue: false,
        units: "05b2cc60-7890-4c2b-b498-dd3cda01370c",
      },
      {
        settingName: "alertOnMinVoltage",
        defaultValue: true,
        units: "0552cc60-7890-4c2b-b498-dd3cda01370c",
      },
      {
        settingName: "alertOnMaxChargeCurrent",
        defaultValue: false,
        units: "06b2cc60-7890-4c2b-b498-dd3cda01370c",
      },
      {
        settingName: "alertOnMaxDischargeCurrent",
        defaultValue: false,
        units: "07b2cc60-7890-4c2b-b498-dd3cda01370c",
      },
      {
        settingName: "numberOfBatteries",
        defaultValue: 1.0,
        units: null,
      },
      { settingName: "isBank", defaultValue: false, units: null },
      {
        settingName: "capacity",
        defaultValue: 90.0,
        units: "Ah",
      },
      {
        settingName: "maxDischargeCurrent@Time",
        defaultValue: 120.0,
        units: "A",
      },
      {
        settingName: "maxDischarge@Time",
        defaultValue: 10.0,
        units: "seconds",
      },
      {
        settingName: "alertOnMaxDischargeCurrent@Time",
        defaultValue: false,
        units: "08b2cc60-7890-4c2b-b498-dd3cda01370c",
      },
      { settingName: "modelUuid", defaultValue: null, units: null },
      {
        settingName: "maxTemperature",
        defaultValue: 225.0,
        units: "F",
      },
      {
        settingName: "alertOnMaxTemperature",
        defaultValue: true,
        units: "17b2cc60-7890-4c2b-b498-dd3cda01370d",
      },
      {
        settingName: "componentUuid",
        defaultValue: "03b2cc60-6890-4c2b-b498-dd3cda01370b",
        units: null,
      },
      {
        settingName: "updateRate",
        defaultValue: 30.0,
        units: "seconds",
      },
      {
        settingName: "alertOnLowSoh",
        defaultValue: false,
        units: "09b2cc60-7890-4c2b-b498-dd3cda01370c",
      },
      {
        settingName: "minSoh",
        defaultValue: 30.0,
        units: "%",
      },
      { settingName: "_typeName", defaultValue: "bms", units: null },
      {
        settingName: "description",
        defaultValue: "This is a BMS",
        units: null,
      },
      {
        settingName: "dataSchema",
        defaultValue: "BatteryData",
        units: "IMPORTANT - SCHEMA NAME IN DB",
      },
      {
        settingName: "enum",
        defaultValue: "BMS",
        units: "ENUM FOR FRONTEND MATCHING IF ID CHANGE",
      },
      { settingName: "name", defaultValue: "Battery", units: null },
      { settingName: "batteryVocation", defaultValue: "HOUSE", units: null },
      {
        settingName: "minTemperature",
        defaultValue: 0.0,
        units: "C",
      },
      {
        settingName: "alertOnMinTemperature",
        defaultValue: true,
        units: "18b2cc60-7890-4c2b-b498-dd3cda01370d",
      },
      {
        settingName: "reportCurrentChange",
        defaultValue: 0.2,
        units: "A",
      },
      {
        settingName: "reportVoltageChange",
        defaultValue: 0.2,
        units: "V",
      },
      {
        settingName: "reportTemperatureChange",
        defaultValue: 5.0,
        units: "C",
      },
    ],
    data: [
      { variableName: "current", units: "A" },
      { variableName: "voltage", units: "V" },
      { variableName: "temperature", units: "C" },
      { variableName: "soc", units: "%" },
      { variableName: "soh", units: "%" },
      { variableName: "charging", units: "boolean" },
      { variableName: "timestamp", units: "epoch time" },
      { variableName: "receiveSignalStrength", units: "dB" },
      { variableName: "receiveLinkQuality", units: null },
      { variableName: "transmitSignalStrength", units: "dB" },
      { variableName: "transmitLinkQuality", units: null },
      { variableName: "crank", units: "boolean" },
    ],
    createdAt: "",
    updatedAt: "",
    _v: 0,
  },
]);

db.createCollection("bilgedefaults");
db.bilgedefaults.insertMany([
  {
    _id: ObjectId("5db06bda3c11f1d7f40a2473"),
    settings: [
      {
        settingName: "deviceTypeId",
        defaultValue: "5908bf9f12ca6430e2000001",
        units: null,
      },
      {
        settingName: "alertMaxOnTime",
        defaultValue: true,
        units: "02b2cc60-7890-4c2b-b498-dd3cda01370c",
      },
      {
        settingName: "updateRate",
        defaultValue: 30.0,
        units: "seconds",
      },
      { settingName: "alertOnTime", defaultValue: true, units: null },
      {
        settingName: "zoneLocation",
        defaultValue: 1.0,
        units: null,
      },
      {
        settingName: "maxOnTime",
        defaultValue: 180.0,
        units: "seconds",
      },
      {
        settingName: "alertMaxFreqInterval",
        defaultValue: 86400.0,
        units: "seconds",
      },
      {
        settingName: "alertMaxFreqCycles",
        defaultValue: 5.0,
        units: null,
      },
      {
        settingName: "componentUuid",
        defaultValue: "01b2cc60-6890-4c2b-b498-dd3cda01370b",
        units: null,
      },
      {
        settingName: "alertOnMaxCurrent",
        defaultValue: true,
        units: "01b2cc60-7890-4c2b-b498-dd3cda01370c",
      },
      {
        settingName: "maxCurrent",
        defaultValue: 7.0,
        units: "A",
      },
      { settingName: "_typeName", defaultValue: "bilge_pump", units: null },
      {
        settingName: "description",
        defaultValue: "Electric water pump to remove bilge water.",
        units: null,
      },
      {
        settingName: "dataSchema",
        defaultValue: "BilgeData",
        units: "IMPORTANT - SCHEMA NAME IN DB",
      },
      {
        settingName: "enum",
        defaultValue: "BILGE_PUMP",
        units: "ENUM FOR FRONTEND MATCHING IF ID CHANGE",
      },
      { settingName: "name", defaultValue: "Bilge Pump", units: null },
      {
        settingName: "alertOnMaxFreq",
        defaultValue: true,
        units: "19b2cc60-7890-4c2b-b498-dd3cda01370d",
      },
      {
        settingName: "maxFreqInterval",
        defaultValue: 86400.0,
        units: "seconds",
      },
      {
        settingName: "maxFreqCycles",
        defaultValue: 5.0,
        units: null,
      },
      {
        settingName: "reportDeltaCurrent",
        defaultValue: 0.1,
        units: "A",
      },
      {
        settingName: "runningCurrent",
        defaultValue: 0.15,
        units: "A",
      },
    ],
    data: [
      { variableName: "current", units: "A" },
      { variableName: "timestamp", units: "epoch time" },
      { variableName: "running", units: "boolean" },
      { variableName: "lastTimestampOn", units: "epoch time" },
      { variableName: "lastTimestampOff", units: "epoch time" },
      { variableName: "receiveSignalStrength", units: "dB" },
      { variableName: "receiveLinkQuality", units: null },
      { variableName: "transmitSignalStrength", units: "dB" },
      { variableName: "transmitLinkQuality", units: null },
      { variableName: "manualSwitch", units: "boolean" },
      { variableName: "currentTrigger", units: "boolean" },
    ],
    createdAt: "",
    updatedAt: "",
    _v: 0,
  },
]);

db.createCollection("enginedefaults");
db.enginedefaults.insertMany([
  {
    _id: ObjectId("5db06bdb3c11f1d7f40a247b"),
    settings: [
      {
        settingName: "deviceTypeId",
        defaultValue: "5908bf9f12ca6430e2000008",
        units: "bilge_pump",
      },
      {
        settingName: "updateRate",
        defaultValue: 30.0,
        units: "seconds",
      },
      {
        settingName: "zoneLocation",
        defaultValue: 1.0,
        units: null,
      },
      { settingName: "installDate", defaultValue: null, units: null },
      {
        settingName: "componentUuid",
        defaultValue: "08b2cc60-6890-4c2b-b498-dd3cda01370b",
        units: "Mercury Engine",
      },
      {
        settingName: "alertOnFault",
        defaultValue: true,
        units: "93b2cc60-7890-4c2b-b498-dd3cda01370c",
      },
      { settingName: "_typeName", defaultValue: "engine", units: null },
      {
        settingName: "description",
        defaultValue: "This is an engine",
        units: null,
      },
      {
        settingName: "dataSchema",
        defaultValue: "EngineData",
        units: "IMPORTANT - SCHEMA NAME IN DB",
      },
      {
        settingName: "enum",
        defaultValue: "ENGINE",
        units: "ENUM FOR FRONTEND MATCHING IF ID CHANGE",
      },
      { settingName: "name", defaultValue: "Engine", units: null },
      {
        settingName: "serviceSoonHours",
        defaultValue: 4000.0,
        units: "hours",
      },
      {
        settingName: "alertOnServiceSoonHours",
        defaultValue: true,
        units: "20b2cc60-7890-4c2b-b498-dd3cda01370d",
      },
      { settingName: "softwareId", defaultValue: null, units: null },
      { settingName: "calibrationId", defaultValue: null, units: null },
      { settingName: "engineSerial", defaultValue: null, units: null },
      {
        settingName: "reportRpmChange",
        defaultValue: 50.0,
        units: "rpm",
      },
      {
        settingName: "reportHoursChange",
        defaultValue: 0.08,
        units: "Hours",
      },
      {
        settingName: "reportCoolantTemp",
        defaultValue: 5.0,
        units: "degrees C",
      },
      { settingName: "reportEngineActive", defaultValue: true, units: "bool" },
    ],
    data: [
      { variableName: "timestamp", units: "epoch time" },
      { variableName: "engineHours", units: "hours" },
      { variableName: "waterPressure", units: "kPa" },
      { variableName: "coolantTemp", units: "degrees C" },
      { variableName: "oilPressure", units: "kPa" },
      { variableName: "oilTemp", units: "degrees C" },
      { variableName: "seaTemp", units: "degrees C" },
      { variableName: "rpm", units: "rpm" },
      { variableName: "voltage", units: "v" },
      { variableName: "engineActive", units: "Enum" },
    ],
    createdAt: "",
    updatedAt: "",
    _v: 0,
  },
]);

db.createCollection("fluidsensordefaults");
db.fluidsensordefaults.insertMany([
  {
    _id: ObjectId("5db06bdb3c11f1d7f40a247d"),
    settings: [
      {
        settingName: "deviceTypeId",
        defaultValue: "5908bf9f12ca6430e2000011",
        units: null,
      },
      {
        settingName: "updateRate",
        defaultValue: 1800.0,
        units: "seconds",
      },
      {
        settingName: "zoneLocation",
        defaultValue: 1.0,
        units: null,
      },
      {
        settingName: "componentUuid",
        defaultValue: "12b2cc60-6890-4c2b-b498-dd3cda01370b",
        units: null,
      },
      { settingName: "_typeName", defaultValue: "fluid_sensor", units: null },
      {
        settingName: "description",
        defaultValue: "This is a fluid sensor",
        units: null,
      },
      {
        settingName: "dataSchema",
        defaultValue: "FluidSensorData",
        units: "IMPORTANT - SCHEMA NAME IN DB",
      },
      {
        settingName: "enum",
        defaultValue: "FLUIDSENSOR",
        units: "ENUM FOR FRONTEND MATCHING IF ID CHANGE",
      },
      { settingName: "name", defaultValue: "fluidsensor", units: null },
      {
        settingName: "tankCapacity",
        defaultValue: 375.0,
        units: "liters",
      },
      {
        settingName: "fluidType",
        defaultValue: 6.0,
        units: "integer",
      },
      {
        settingName: "minLevel",
        defaultValue: 10.0,
        units: "%",
      },
      {
        settingName: "alertOnMinLevel",
        defaultValue: true,
        units: "25b2cc60-7890-4c2b-b498-dd3cda01370d",
      },
      {
        settingName: "maxLevel",
        defaultValue: 100.0,
        units: "%",
      },
      {
        settingName: "alertOnMaxLevel",
        defaultValue: true,
        units: "26b2cc60-7890-4c2b-b498-dd3cda01370d",
      },
      {
        settingName: "reportLevelDelta",
        defaultValue: 5.0,
        units: "%",
      },
      { settingName: "nmeaName", defaultValue: null, units: null },
      { settingName: "sourceAddress", defaultValue: null, units: "decimal" },
      {
        settingName: "instance",
        defaultValue: 0.0,
        units: "integer",
      },
    ],
    data: [
      { variableName: "timestamp", units: "epoch time" },
      { variableName: "level", units: "decimal" },
    ],
    createdAt: "",
    updatedAt: "",
    _v: 0,
  },
]);

db.createCollection("gpsdefaults");
db.gpsdefaults.insertMany([
  {
    _id: ObjectId("5db06bda3c11f1d7f40a2478"),
    settings: [
      {
        settingName: "deviceTypeId",
        defaultValue: "5908bf9f12ca6430e2000006",
        units: null,
      },
      {
        settingName: "updateRate",
        defaultValue: 30.0,
        units: "seconds",
      },
      {
        settingName: "zoneLocation",
        defaultValue: 1.0,
        units: null,
      },
      { settingName: "installDate", defaultValue: null, units: null },
      { settingName: "zoneLocation", defaultValue: null, units: null },
      {
        settingName: "componentUuid",
        defaultValue: "04b2cc60-6890-4c2b-b498-dd3cda01370b",
        units: null,
      },
      { settingName: "geofenceLatitude", defaultValue: null, units: "deg" },
      { settingName: "geofenceLongitude", defaultValue: null, units: "deg" },
      { settingName: "geofenceRadius", defaultValue: null, units: "ft" },
      {
        settingName: "geofenceAngle",
        defaultValue: 360.0,
        units: "deg",
      },
      {
        settingName: "geofenceDirection",
        defaultValue: 0.0,
        units: "deg",
      },
      { settingName: "geofencePolygonPoints", defaultValue: null, units: null },
      {
        settingName: "geofenceGeometryTypeEnum",
        defaultValue: "RADIAL",
        units: null,
      },
      {
        settingName: "alertOnOutsideFence",
        defaultValue: true,
        units: "11b2cc60-7890-4c2b-b498-dd3cda01370c",
      },
      { settingName: "geofenceEnabled", defaultValue: false, units: null },
      { settingName: "isGeofenceFavorite", defaultValue: false, units: null },
      {
        settingName: "currentGeoFenceFavoriteName",
        defaultValue: null,
        units: null,
      },
      { settingName: "_typeName", defaultValue: "gps", units: null },
      { settingName: "description", defaultValue: "This is GPS", units: null },
      {
        settingName: "dataSchema",
        defaultValue: "GpsData",
        units: "IMPORTANT - SCHEMA NAME IN DB",
      },
      {
        settingName: "enum",
        defaultValue: "GPS",
        units: "ENUM FOR FRONTEND MATCHING IF ID CHANGE",
      },
      { settingName: "name", defaultValue: "GPS", units: null },
      {
        settingName: "reportLatitudeChange",
        defaultValue: 0.0001,
        units: "deg",
      },
      {
        settingName: "reportLongitudeChange",
        defaultValue: 0.0001,
        units: "deg",
      },
    ],
    data: [
      { variableName: "timestamp", units: "epoch time" },
      { variableName: "latitude", units: null },
      { variableName: "longitude", units: null },
      { variableName: "speed", units: "miles per hour" },
      { variableName: "quality", units: null },
    ],
    createdAt: "",
    updatedAt: "",
    _v: 0,
  },
]);

db.createCollection("hubdefaults");
db.hubdefaults.insertMany([
  {
    _id: ObjectId("5db06bdb3c11f1d7f40a247c"),
    settings: [
      {
        settingName: "deviceTypeId",
        defaultValue: "5908bf9f12ca6430e2000010",
        units: null,
      },
      {
        settingName: "updateRate",
        defaultValue: 1800.0,
        units: "seconds",
      },
      {
        settingName: "zoneLocation",
        defaultValue: 1.0,
        units: null,
      },
      { settingName: "componentUuid", defaultValue: "uuid", units: null },
      { settingName: "_typeName", defaultValue: "hub", units: null },
      {
        settingName: "description",
        defaultValue: "This is a hub puck",
        units: null,
      },
      {
        settingName: "dataSchema",
        defaultValue: "HubData",
        units: "IMPORTANT - SCHEMA NAME IN DB",
      },
      {
        settingName: "enum",
        defaultValue: "HUB",
        units: "ENUM FOR FRONTEND MATCHING IF ID CHANGE",
      },
      { settingName: "name", defaultValue: "Hub", units: null },
      {
        settingName: "alertOnDidNotReport",
        defaultValue: false,
        units: "22b2cc60-7890-4c2b-b498-dd3cda01370d",
      },
      {
        settingName: "alertOnComponentNotReport",
        defaultValue: false,
        units: "23b2cc60-7890-4c2b-b498-dd3cda01370d",
      },
    ],
    data: [
      { variableName: "timestamp", units: "epoch time" },
      { variableName: "pucksCurrentlyConnected", units: "integer" },
      { variableName: "lastPuckReportedTime", units: "epoch time" },
      { variableName: "lteSignalStrength", units: "dB" },
    ],
    createdAt: "",
    updatedAt: "",
    _v: 0,
  },
]);

db.createCollection("motiondefaults");
db.motiondefaults.insertMany([
  {
    _id: ObjectId("5db06bda3c11f1d7f40a2476"),
    settings: [
      {
        settingName: "deviceTypeId",
        defaultValue: "5908bf9f12ca6430e2000003",
        units: null,
      },
      {
        settingName: "updateRate",
        defaultValue: 30.0,
        units: "seconds",
      },
      {
        settingName: "zoneLocation",
        defaultValue: 1.0,
        units: null,
      },
      { settingName: "installDate", defaultValue: null, units: null },
      { settingName: "zoneLocation", defaultValue: null, units: null },
      {
        settingName: "componentUuid",
        defaultValue: "02b2cc60-6890-4c2b-b498-dd3cda01370b",
        units: null,
      },
      {
        settingName: "alertOnTrigger",
        defaultValue: true,
        units: "10b2cc60-7890-4c2b-b498-dd3cda01370c",
      },
      {
        settingName: "sensitivity",
        defaultValue: 5.0,
        units: "scale 1-5",
      },
      {
        settingName: "takeImageOnMotion",
        defaultValue: true,
        units: "if camera is available",
      },
      { settingName: "_typeName", defaultValue: "motion", units: null },
      {
        settingName: "description",
        defaultValue: "This is a motion sensor",
        units: null,
      },
      {
        settingName: "dataSchema",
        defaultValue: "MotionData",
        units: "IMPORTANT - SCHEMA NAME IN DB",
      },
      {
        settingName: "enum",
        defaultValue: "MOTION",
        units: "ENUM FOR FRONTEND MATCHING IF ID CHANGE",
      },
      { settingName: "name", defaultValue: "Motion Sensor", units: null },
    ],
    data: [
      { variableName: "lastTimestampTriggered", units: "epoch time" },
      { variableName: "armed", units: "boolean" },
      { variableName: "timestamp", units: "epoch time" },
      { variableName: "motionDetected", units: "boolean" },
      { variableName: "receiveSignalStrength", units: "dB" },
      { variableName: "receiveLinkQuality", units: null },
      { variableName: "transmitSignalStrength", units: "dB" },
      { variableName: "transmitLinkQuality", units: null },
    ],
    createdAt: "",
    updatedAt: "",
    _v: 0,
  },
]);

db.createCollection("relaydefaults");
db.relaydefaults.insertMany([
  {
    _id: ObjectId("5db06bdb3c11f1d7f40a2479"),
    settings: [
      {
        settingName: "deviceTypeId",
        defaultValue: "5908bf9f12ca6430e2000005",
        units: null,
      },
      {
        settingName: "updateRate",
        defaultValue: 30.0,
        units: "seconds",
      },
      {
        settingName: "zoneLocation",
        defaultValue: 1.0,
        units: null,
      },
      { settingName: "installDate", defaultValue: null, units: null },
      { settingName: "zoneLocation", defaultValue: null, units: null },
      {
        settingName: "componentUuid",
        defaultValue: "07b2cc60-6890-4c2b-b498-dd3cda01370b",
        units: null,
      },
      {
        settingName: "alertOnSwitchClose",
        defaultValue: false,
        units: "13b2cc60-7890-4c2b-b498-dd3cda01370c",
      },
      {
        settingName: "alertOnSwitchOpen",
        defaultValue: false,
        units: "12b2cc60-7890-4c2b-b498-dd3cda01370c",
      },
      { settingName: "closedAsDefault", defaultValue: true, units: null },
      { settingName: "closedOnPower", defaultValue: false, units: null },
      {
        settingName: "attachedTo",
        defaultValue: null,
        units: "string if no component",
      },
      { settingName: "attachedComponentUuid", defaultValue: null, units: null },
      { settingName: "_typeName", defaultValue: "relay", units: null },
      {
        settingName: "description",
        defaultValue: "This is a relay",
        units: null,
      },
      {
        settingName: "dataSchema",
        defaultValue: "RelayData",
        units: "IMPORTANT - SCHEMA NAME IN DB",
      },
      {
        settingName: "enum",
        defaultValue: "RELAY",
        units: "ENUM FOR FRONTEND MATCHING IF ID CHANGE",
      },
      { settingName: "name", defaultValue: "Relay", units: null },
    ],
    data: [
      { variableName: "timestamp", units: "epoch time" },
      { variableName: "closed", units: "boolean" },
      { variableName: "open", units: "boolean" },
      { variableName: "timestampOfLastChange", units: "epoch time" },
      { variableName: "receiveSignalStrength", units: "dB" },
      { variableName: "receiveLinkQuality", units: null },
      { variableName: "transmitSignalStrength", units: "dB" },
      { variableName: "transmitLinkQuality", units: null },
    ],
    createdAt: "",
    updatedAt: "",
    _v: 0,
  },
]);

db.createCollection("repeaterdefaults");
db.repeaterdefaults.insertMany([
  {
    _id: ObjectId("5db06bda3c11f1d7f40a2474"),
    settings: [
      {
        settingName: "deviceTypeId",
        defaultValue: "5908bf9f12ca6430e2000009",
        units: null,
      },
      {
        settingName: "maxNumberOfConnections",
        defaultValue: 200.0,
        units: null,
      },
      {
        settingName: "updateRate",
        defaultValue: 30.0,
        units: "seconds",
      },
      { settingName: "installDate", defaultValue: null, units: null },
      { settingName: "zoneLocation", defaultValue: null, units: null },
      {
        settingName: "componentUuid",
        defaultValue: "10b2cc60-5890-4c2b-b498-dd3cda01370a",
        units: null,
      },
      { settingName: "_typeName", defaultValue: "repeater", units: null },
      {
        settingName: "description",
        defaultValue: "This is a repeater",
        units: null,
      },
      {
        settingName: "dataSchema",
        defaultValue: "RepeaterData",
        units: "IMPORTANT - SCHEMA NAME IN DB",
      },
      {
        settingName: "enum",
        defaultValue: "REPEATER",
        units: "ENUM FOR FRONTEND MATCHING IF ID CHANGE",
      },
      { settingName: "name", defaultValue: "Repeater", units: null },
    ],
    data: [
      { variableName: "current", units: "A" },
      { variableName: "connections", units: "integer" },
      { variableName: "otherData", units: "?" },
      { variableName: "timestamp", units: "epoch time" },
      { variableName: "timeOn", units: "seconds" },
      { variableName: "receiveSignalStrength", units: "dB" },
      { variableName: "receiveLinkQuality", units: null },
      { variableName: "transmitSignalStrength", units: "dB" },
      { variableName: "transmitLinkQuality", units: null },
    ],
    createdAt: "",
    updatedAt: "",
    _v: 0,
  },
]);

db.createCollection("shorepowerdefaults");
db.shorepowerdefaults.insertMany([
  {
    _id: ObjectId("5db06bdb3c11f1d7f40a247a"),
    settings: [
      {
        settingName: "deviceTypeId",
        defaultValue: "5908bf9f12ca6430e2000007",
        units: null,
      },
      {
        settingName: "updateRate",
        defaultValue: 30.0,
        units: "seconds",
      },
      {
        settingName: "zoneLocation",
        defaultValue: 1.0,
        units: null,
      },
      { settingName: "installDate", defaultValue: null, units: null },
      {
        settingName: "componentUuid",
        defaultValue: "06b2cc60-6890-4c2b-b498-dd3cda01370b",
        units: null,
      },
      {
        settingName: "alertOnConnect",
        defaultValue: false,
        units: "15b2cc60-7890-4c2b-b498-dd3cda01370c",
      },
      {
        settingName: "alertOnDisconnect",
        defaultValue: true,
        units: "14b2cc60-7890-4c2b-b498-dd3cda01370c",
      },
      { settingName: "_typeName", defaultValue: "shorepower", units: null },
      {
        settingName: "description",
        defaultValue: "This is shorepower",
        units: null,
      },
      {
        settingName: "dataSchema",
        defaultValue: "ShorepowerData",
        units: "IMPORTANT - SCHEMA NAME IN DB",
      },
      {
        settingName: "enum",
        defaultValue: "SHOREPOWER",
        units: "ENUM FOR FRONTEND MATCHING IF ID CHANGE",
      },
      { settingName: "name", defaultValue: "Shorepower", units: null },
    ],
    data: [
      { variableName: "timestamp", units: "epoch time" },
      { variableName: "disconnected", units: "boolean" },
      { variableName: "connected", units: "boolean" },
      { variableName: "timestampOfLastConnect", units: "epoch time" },
      { variableName: "timestampOfLastDisconnect", units: "epoch time" },
      { variableName: "lastConnectedTime", units: "time in seconds" },
      { variableName: "receiveSignalStrength", units: "dB" },
      { variableName: "receiveLinkQuality", units: null },
      { variableName: "transmitSignalStrength", units: "dB" },
      { variableName: "transmitLinkQuality", units: null },
    ],
    createdAt: "",
    updatedAt: "",
    _v: 0,
  },
]);

db.createCollection("cameradefaults");
db.cameradefaults.insertMany([
  {
    _id: ObjectId("5db06bda3c11f1d7f40a2477"),
    settings: [
      {
        settingName: "deviceTypeId",
        defaultValue: "5908bf9f12ca6430e2000004",
        units: null,
      },
      {
        settingName: "updateRate",
        defaultValue: 900.0,
        units: "seconds",
      },
      {
        settingName: "zoneLocation",
        defaultValue: 1.0,
        units: null,
      },
      { settingName: "installDate", defaultValue: null, units: null },
      {
        settingName: "componentUuid",
        defaultValue: "05b2cc60-6890-4c2b-b498-dd3cda01370b",
        units: null,
      },
      {
        settingName: "resolutionX",
        defaultValue: 1920.0,
        units: "px",
      },
      {
        settingName: "resolutionY",
        defaultValue: 1080.0,
        units: "px",
      },
      {
        settingName: "frameRate",
        defaultValue: 1.0,
        units: "fps",
      },
      { settingName: "encoding", defaultValue: "h264", units: null },
      { settingName: "_typeName", defaultValue: "camera", units: null },
      {
        settingName: "description",
        defaultValue: "This is a camera",
        units: null,
      },
      {
        settingName: "dataSchema",
        defaultValue: "CameraData",
        units: "IMPORTANT - SCHEMA NAME IN DB",
      },
      {
        settingName: "enum",
        defaultValue: "CAMERA",
        units: "ENUM FOR FRONTEND MATCHING IF ID CHANGE",
      },
      { settingName: "name", defaultValue: "Camera", units: null },
    ],
    data: [
      { variableName: "image", units: "base64" },
      { variableName: "timestamp", units: "epoch time" },
      { variableName: "receiveSignalStrength", units: "dB" },
      { variableName: "receiveLinkQuality", units: null },
      { variableName: "transmitSignalStrength", units: "dB" },
      { variableName: "transmitLinkQuality", units: null },
    ],
    createdAt: "",
    updatedAt: "",
    _v: 0,
  },
]);
