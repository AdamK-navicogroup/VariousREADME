db = db.getSiblingDB(_getEnv("CV_EMPOWER_MONGO_DB"));
db.createCollection("Entity");

db.Entity.insertMany([
    {
        _id: ObjectId("62b7d258bb0e46fcb511f076"),
        name: "Rahul's Boat",
        isDeleted: false,
        type: "boat",
        hin: "test-europa-boat",
        vin: "",
        location: "US",
        __v: { $numberInt: "0" },
        metadata: {
            "europa:oemBrand": "SR",
        },
    },
    {
        _id: ObjectId("62b7d258bb0e46fcb511f077"),
        name: "Rahul's Old Boat",
        isDeleted: false,
        type: "boat",
        hin: "test-nauticon-boat",
        vin: "bcde2345",
        location: "US",
        __v: { $numberInt: "0" },
    },
]);
