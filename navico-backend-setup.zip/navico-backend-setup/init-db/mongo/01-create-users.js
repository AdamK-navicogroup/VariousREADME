// Empower

db = db.getSiblingDB(_getEnv("CV_EMPOWER_MONGO_DB"));
db.createUser({
    user: _getEnv("CV_EMPOWER_MONGO_USER"),
    pwd: _getEnv("CV_EMPOWER_MONGO_PASS"),
    roles: [
        {
            role: "readWrite",
            db: _getEnv("CV_EMPOWER_MONGO_DB"),
        },
        {
            role: "userAdmin",
            db: _getEnv("CV_EMPOWER_MONGO_DB"),
        },
        {
            role: "root",
            db: "admin",
        },
    ],
});

// Factory domain
db = db.getSiblingDB(_getEnv("CV_FACTORY_MONGO_DB"));
db.createUser({
    user: _getEnv("CV_FACTORY_MONGO_USER"),
    pwd: _getEnv("CV_FACTORY_MONGO_PASS"),
    roles: [
        {
            role: "readWrite",
            db: _getEnv("CV_FACTORY_MONGO_DB"),
        },
        {
            role: "userAdmin",
            db: _getEnv("CV_FACTORY_MONGO_DB"),
        },
        {
            role: "root",
            db: "admin",
        },
    ],
});

// Nauticon
db = db.getSiblingDB(_getEnv("CV_MONGO_DEVICE_DB"));
db.createUser({
    user: _getEnv("CV_MONGO_DEVICE_USER"),
    pwd: _getEnv("CV_MONGO_DEVICE_PASS"),
    roles: [
        {
            role: "readWrite",
            db: _getEnv("CV_MONGO_DEVICE_DB"),
        },
        {
            role: "userAdmin",
            db: _getEnv("CV_MONGO_DEVICE_DB"),
        },
        {
            role: "root",
            db: "admin",
        },
    ],
});

// Engage
db = db.getSiblingDB(_getEnv("CV_ENGAGE_MONGO_DB"));
db.createUser({
    user: _getEnv("CV_ENGAGE_MONGO_USER"),
    pwd: _getEnv("CV_ENGAGE_MONGO_PASS"),
    roles: [
        {
            role: "readWrite",
            db: _getEnv("CV_ENGAGE_MONGO_DB"),
        },
        {
            role: "userAdmin",
            db: _getEnv("CV_ENGAGE_MONGO_DB"),
        },
        {
            role: "root",
            db: "admin",
        },
    ],
});

// Empower core

// iot
db = db.getSiblingDB("iot");
db.createUser({
    user: _getEnv("MONGO_INITDB_ROOT_USERNAME"),
    pwd: _getEnv("MONGO_INITDB_ROOT_PASSWORD"),
    roles: [
        {
            role: "readWrite",
            db: _getEnv("MONGO_INITDB_ROOT_USERNAME"),
        },
        {
            role: "userAdmin",
            db: _getEnv("MONGO_INITDB_ROOT_PASSWORD"),
        },
        {
            role: "root",
            db: "admin",
        },
    ],
});

// factory
db = db.getSiblingDB("factory");
db.createUser({
    user: _getEnv("MONGO_INITDB_ROOT_USERNAME"),
    pwd: _getEnv("MONGO_INITDB_ROOT_PASSWORD"),
    roles: [
        {
            role: "readWrite",
            db: _getEnv("MONGO_INITDB_ROOT_USERNAME"),
        },
        {
            role: "userAdmin",
            db: _getEnv("MONGO_INITDB_ROOT_PASSWORD"),
        },
        {
            role: "root",
            db: "admin",
        },
    ],
});

// trips
db = db.getSiblingDB("trips");
db.createUser({
    user: _getEnv("MONGO_INITDB_ROOT_USERNAME"),
    pwd: _getEnv("MONGO_INITDB_ROOT_PASSWORD"),
    roles: [
        {
            role: "readWrite",
            db: _getEnv("MONGO_INITDB_ROOT_USERNAME"),
        },
        {
            role: "userAdmin",
            db: _getEnv("MONGO_INITDB_ROOT_PASSWORD"),
        },
        {
            role: "root",
            db: "admin",
        },
    ],
});

// user
db = db.getSiblingDB("user");
db.createUser({
    user: _getEnv("MONGO_INITDB_ROOT_USERNAME"),
    pwd: _getEnv("MONGO_INITDB_ROOT_PASSWORD"),
    roles: [
        {
            role: "readWrite",
            db: _getEnv("MONGO_INITDB_ROOT_USERNAME"),
        },
        {
            role: "userAdmin",
            db: _getEnv("MONGO_INITDB_ROOT_PASSWORD"),
        },
        {
            role: "root",
            db: "admin",
        },
    ],
});
