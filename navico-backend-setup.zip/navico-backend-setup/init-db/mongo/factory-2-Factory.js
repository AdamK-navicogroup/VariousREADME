db = db.getSiblingDB("factory");
db.createCollection("Factory");

db.Factory.insertMany([
    {
        _id: ObjectId("6402203667efd5421420600a"),
        name: "Bob's Boat Maker",
        crmConfig: {
            _id: ObjectId("6402203667efd5421420600b"),
        },
        oems: ["6345871eea4611f5d78c140d"],
        location: [0, 0],
        isDeleted: false,
    },
]);
