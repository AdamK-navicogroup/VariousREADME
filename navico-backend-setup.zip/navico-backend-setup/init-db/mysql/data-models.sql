#
# Copyright (c) 2015 - 2017. Technicity LLC. All rights reserved.
#
DROP DATABASE IF EXISTS `CV_Device`;
CREATE SCHEMA IF NOT EXISTS `CV_Device`
  DEFAULT CHARACTER SET utf8
  COLLATE utf8_general_ci;
USE `CV_Device`;

-- -----------------------------------------------------
-- Table `Authorization`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Authorization`;

CREATE TABLE IF NOT EXISTS `Authorization` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `serviceName` VARCHAR(255) NOT NULL,
  `key`         VARCHAR(255) NOT NULL,
  `secret`      VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB;

INSERT INTO Authorization (`serviceName`, `key`, `secret`) VALUES ('testService', 'key', SHA2('secret', 256));


DROP DATABASE IF EXISTS CV_AggregateData;
CREATE SCHEMA IF NOT EXISTS CV_AggregateData
  DEFAULT CHARACTER SET utf8
  COLLATE utf8_general_ci;
USE CV_AggregateData;

ALTER DATABASE CHARACTER SET utf8mb4
COLLATE utf8mb4_general_ci;

DROP TABLE IF EXISTS Authorization;

CREATE TABLE IF NOT EXISTS Authorization (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `serviceName` VARCHAR(255) NOT NULL,
  `key`         VARCHAR(255) NOT NULL,
  `secret`      VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = utf8;

ALTER TABLE Authorization
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

-- This should be moved to separate file
INSERT INTO Authorization (`serviceName`, `key`, `secret`) VALUES ('testService', 'key', SHA2('secret', 256));



DROP DATABASE IF EXISTS CV_Alert;
CREATE SCHEMA IF NOT EXISTS CV_Alert
  DEFAULT CHARACTER SET utf8
  COLLATE utf8_general_ci;
USE CV_Alert;

ALTER DATABASE CV_Alert
CHARACTER SET utf8mb4
COLLATE utf8mb4_general_ci;

DROP TABLE IF EXISTS Authorization;

CREATE TABLE IF NOT EXISTS Authorization (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `serviceName` VARCHAR(255) NOT NULL,
  `key`         VARCHAR(255) NOT NULL,
  `secret`      VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE Authorization
  CONVERT TO CHARACTER SET utf8
  COLLATE utf8_general_ci;

ALTER TABLE Authorization
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

INSERT INTO Authorization (`serviceName`, `key`, `secret`) VALUES ('testService', 'key', SHA2('secret', 256));

DROP TABLE IF EXISTS Severity;
CREATE TABLE IF NOT EXISTS Severity (
  `id`               BIGINT       NOT NULL     AUTO_INCREMENT,
  `uuid`             BINARY(36)   NOT NULL,
  `name`             VARCHAR(255) NOT NULL,
  `title`            VARCHAR(255) NOT NULL,
  `rating`           INTEGER      NOT NULL,
  `actionText`       TEXT         NULL,
  `shortDescription` TEXT         NULL,
  `longDescription`  TEXT         NULL,
  `valid`            TINYINT(1)   NOT NULL     DEFAULT 1,
  `lastAccess`       TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`          TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid` (`uuid`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE Severity
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX uuid,
  ADD UNIQUE INDEX uuid_idx (uuid);

# TODO: Move insert statements to separate DML SQL file
INSERT INTO Severity
SET uuid = UUID(), name = 'NOTIFICATION', title = 'Notification', rating = 0;
INSERT INTO Severity
SET uuid = UUID(), name = 'LOW', title = 'Address Soon', rating = 1;
INSERT INTO Severity
SET uuid = UUID(), name = 'MEDIUM', title = 'Address ASAP', rating = 2;
INSERT INTO Severity
SET uuid = UUID(), name = 'HIGH', title = 'Critical', rating = 3;
INSERT INTO Severity
SET uuid = UUID(), name = 'FATAL', title = 'Complete Failure', rating = 4;

DROP TABLE IF EXISTS Alert;
CREATE TABLE IF NOT EXISTS Alert (
  `id`                     BIGINT        NOT NULL AUTO_INCREMENT,
  `uuid`                   BINARY(36)    NOT NULL,
  `name`                   VARCHAR(255)  NOT NULL,
  `title`                  VARCHAR(255)  NOT NULL,
  `headline`               VARCHAR(255)  NULL,
  `shortDescription`       VARCHAR(512)  NULL,
  `longDescription`        TEXT          NULL,
  `failureTypeDescription` VARCHAR(1024) NULL,
  `faultTypeDescription`   VARCHAR(1024) NULL,
  `severityId`             BIGINT        NOT NULL,
  `actionText`             TEXT          NULL,
  `deviceTypeId`           VARCHAR(36)   NULL,
  `valid`                  TINYINT(1)    NOT NULL     DEFAULT 1,
  `lastAccess`             TIMESTAMP     NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`                TIMESTAMP     NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `alert_severity_fk` FOREIGN KEY (`severityId`) REFERENCES `Severity` (`id`),
  INDEX `uuid` (`uuid`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE Alert
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX uuid,
  ADD UNIQUE INDEX uuid_idx (uuid);

# TODO: Move these to separate file
-- INSERT INTO Alert SET uuid=UUID(), name='BILGE_MAX_CURRENT', title='Bilge Pump', severityId=3;
-- INSERT INTO Alert SET uuid=UUID(), name='BILGE_OVER_TIME', title='Engine';
-- INSERT INTO Alert SET uuid=UUID(), name='ENGINE_FAULT', title='Refrigerator';
-- INSERT INTO Alert SET uuid=UUID(), name='MOTION_DETECTED', title='Helm System';
-- INSERT INTO Alert SET uuid=UUID(), name='RELAY_OPEN', title='Battery';
-- INSERT INTO Alert SET uuid=UUID(), name='RELAY_CLOSE', title='Genset';
-- INSERT INTO Alert SET uuid=UUID(), name='POWER_PRESENT', title='Motion Sensor';
-- INSERT INTO Alert SET uuid=UUID(), name='POWER_ABSENT', title='Camera';
-- INSERT INTO Alert SET uuid=UUID(), name='RH_THRESH_HIGH', title='Temperature';
-- INSERT INTO Alert SET uuid=UUID(), name='RH_THRESH_LOW', title='Humidity';
-- INSERT INTO Alert SET uuid=UUID(), name='TEMP_HIGHv', title='Shorepower';
-- INSERT INTO Alert SET uuid=UUID(), name='TEMP_LOW', title='GPS';
-- INSERT INTO Alert SET uuid=UUID(), name='RH_TARGET_REACHED', title='GPS';
-- INSERT INTO Alert SET uuid=UUID(), name='TEMP_TARGET_REACHED', title='GPS';
-- INSERT INTO Alert SET uuid=UUID(), name='FWE_FLASH_FAIL', title='GPS', severityId=4;
-- INSERT INTO Alert SET uuid=UUID(), name='FW_FLASH_SUCCESS', title='GPS';
-- INSERT INTO Alert SET uuid=UUID(), name='BMS_LOW_SOC', title='GPS';
-- INSERT INTO Alert SET uuid=UUID(), name='BMS_HIGH_SOC', title='GPS';
-- INSERT INTO Alert SET uuid=UUID(), name='BMS_MAX_V', title='GPS';
-- INSERT INTO Alert SET uuid=UUID(), name='BMS_MIN_V', title='GPS';
-- INSERT INTO Alert SET uuid=UUID(), name='BMS_MAX_SOH', title='GPS';
-- INSERT INTO Alert SET uuid=UUID(), name='BMS_MIN_SOH', title='GPS';
-- INSERT INTO Alert SET uuid=UUID(), name='BMS_MIN_CURR', title='GPS';
-- INSERT INTO Alert SET uuid=UUID(), name='BMS_MAX_CURR', title='GPS';
-- INSERT INTO Alert SET uuid=UUID(), name='BMS_MAX_CURR@T', title='GPS';
-- INSERT INTO Alert SET uuid=UUID(), name='BMS_MIN_CURR@T', title='GPS';
-- INSERT INTO Alert SET uuid=UUID(), name='GPS_OUTSIDE_FENCE', title='GPS';


DROP TABLE IF EXISTS FaultCodeCache;
CREATE TABLE IF NOT EXISTS FaultCodeCache (
  `id`                     BIGINT       NOT NULL AUTO_INCREMENT,
  `uuid`                   BINARY(36)   NOT NULL,
  `alertUuid`              BINARY(36)   NOT NULL,
  `title`                  VARCHAR(255) NULL,
  `faultId`                INTEGER      NULL,
  `typeId`                 INTEGER      NULL,
  `actionId`               INTEGER      NULL,
  `longId`                 INTEGER      NULL,
  `shortId`                INTEGER      NULL,
  `actionText`             VARCHAR(255) NULL,
  `shortDescription`       VARCHAR(255) NULL,
  `headline`               VARCHAR(255) NULL,
  `longDescription`        TEXT         NULL,
  `failureTypeDescription` VARCHAR(255) NULL,
  `faultTypeDescription`   VARCHAR(255) NULL,
  `softwareId`             VARCHAR(255) NULL,
  `deviceTypeId`           VARCHAR(24)  NULL,
  `type`                   VARCHAR(10)  NULL,
  `language`               VARCHAR(2)   NOT NULL     DEFAULT 'en',
  `country`                VARCHAR(2)   NOT NULL     DEFAULT 'us',
  `name`                   VARCHAR(255) NULL,
  `valid`                  TINYINT(1)   NOT NULL     DEFAULT 1,
  `lastAccess`             TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`                TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid` (`uuid`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE FaultCodeCache
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX uuid,
  ADD UNIQUE INDEX uuid_idx (uuid);

DROP TABLE IF EXISTS EngineFault;
CREATE TABLE IF NOT EXISTS EngineFault (
  `id`               BIGINT       NOT NULL AUTO_INCREMENT,
  `uuid`             BINARY(36)   NOT NULL,
  `componentUuid`    BINARY(36)   NOT NULL,
  `name`             VARCHAR(255) NOT NULL,
  `code`             VARCHAR(255) NOT NULL,
  `title`            VARCHAR(255) NOT NULL,
  `shortDescription` VARCHAR(512) NULL,
  `longDescription`  TEXT         NULL,
  `severityId`       BIGINT       NOT NULL,
  `actionText`       TEXT         NULL,
  `valid`            TINYINT(1)   NOT NULL     DEFAULT 1,
  `lastAccess`       TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`          TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `enginefault_severity_fk` FOREIGN KEY (`severityId`) REFERENCES `Severity` (`id`),
  INDEX `uuid` (`uuid`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE EngineFault
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX uuid,
  ADD UNIQUE INDEX uuid_idx (uuid);

# TODO: Move this to separate file
INSERT INTO EngineFault
SET uuid     = UUID(), code = '128', name = 'O2_SENSOR_FAILURE', title = '02 Sensor Failure', componentUuid = UUID(),
  actionText = 'Take care of it.', severityId = (SELECT id
                                                 FROM Severity
                                                 WHERE name = 'NOTIFICATION');


DROP DATABASE IF EXISTS CV_BoatOwner;
CREATE SCHEMA IF NOT EXISTS CV_BoatOwner
  DEFAULT CHARACTER SET utf8
  COLLATE utf8_general_ci;
USE CV_BoatOwner;

ALTER DATABASE CHARACTER SET utf8mb4
COLLATE utf8mb4_general_ci;

DROP TABLE IF EXISTS Authorization;

CREATE TABLE IF NOT EXISTS Authorization (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `serviceName` VARCHAR(255) NOT NULL,
  `key`         VARCHAR(255) NOT NULL,
  `secret`      VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE Authorization
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

-- This should be moved to separate file
INSERT INTO Authorization (`serviceName`, `key`, `secret`) VALUES ('testService', 'key', SHA2('secret', 256));


DROP TABLE IF EXISTS BoatOwner;
-- index UUID
CREATE TABLE IF NOT EXISTS BoatOwner (
  `id`                              BIGINT      NOT NULL AUTO_INCREMENT,
  `uuid`                            BINARY(36)  NOT NULL,
  `userUuid`                        BINARY(36)  NOT NULL,
  `primaryBoatUuid`                 BINARY(36)  NULL,
  `boatOwnerMaintenanceCode`        VARCHAR(10) NOT NULL,
  `hasAcceptedLocationDataTerms`    TINYINT(1)  NOT NULL DEFAULT 0,
  `valid`                           TINYINT(1)  NOT NULL DEFAULT 1,
  `lastAccess`                      TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`                         TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid` (`uuid`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE BoatOwner
  ADD INDEX useruuid_idx (userUuid);

ALTER TABLE BoatOwner
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX `uuid`,
  ADD UNIQUE INDEX uuid_idx (`uuid`);

DROP TABLE IF EXISTS MobileDevice;
CREATE TABLE IF NOT EXISTS MobileDevice (
  `id`                   BIGINT       NOT NULL     AUTO_INCREMENT,
  `boatOwnerId`          BIGINT       NOT NULL,
  `uuid`                 BINARY(36)   NOT NULL,
  `mobileDeviceId`       VARCHAR(255) NOT NULL,
  `osVersion`            VARCHAR(225) NOT NULL,
  `osType`               VARCHAR(225) NOT NULL,
  `mobileDeviceType`     VARCHAR(225) NOT NULL,
  `mobileDeviceBrand`    VARCHAR(255) NOT NULL,
  `mobileDeviceProvider` VARCHAR(255) NOT NULL,
  `commToken`            VARCHAR(255) NULL,
  `expiration`           BIGINT       NOT NULL     DEFAULT 0,
  `valid`                TINYINT(1)   NOT NULL     DEFAULT 1,
  `lastAccess`           TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`              TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `boatOwnerId` (`boatOwnerId`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE MobileDevice
  ADD FOREIGN KEY (`boatOwnerId`) REFERENCES BoatOwner (`id`);
ALTER TABLE MobileDevice
  ADD INDEX uuid_idx (uuid);

ALTER TABLE MobileDevice
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

DROP TABLE IF EXISTS BoatOwnerGPS;
CREATE TABLE IF NOT EXISTS BoatOwnerGPS (
  `id`             BIGINT       NOT NULL     AUTO_INCREMENT,
  `boatOwnerId`    BIGINT       NOT NULL,
  `mobileDeviceId` BIGINT       NOT NULL,
  `timestamp`      BIGINT       NOT NULL,
  `lat`            VARCHAR(255) NULL,
  `lng`            VARCHAR(255) NULL,
  `valid`          TINYINT(1)   NOT NULL     DEFAULT 1,
  `lastAccess`     TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`        TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `boatOwnerId_GPS_fk` FOREIGN KEY (`boatOwnerId`) REFERENCES `BoatOwner` (`id`),
  CONSTRAINT `mobileDeviceId_GPS_fk` FOREIGN KEY (`mobileDeviceId`) REFERENCES `MobileDevice` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE BoatOwnerGPS
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

DROP TABLE IF EXISTS Preferences;
CREATE TABLE IF NOT EXISTS Preferences (
  `id`                   BIGINT     NOT NULL     AUTO_INCREMENT,
  `uuid`                 BINARY(36) NOT NULL,
  `boatOwnerId`          BIGINT     NOT NULL,
  `receiveMarketingComm` TINYINT(1) NOT NULL,
  `receiveAlertComm`     TINYINT(1) NOT NULL,
  `valid`                TINYINT(1) NOT NULL     DEFAULT 1,
  `lastAccess`           TIMESTAMP  NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`              TIMESTAMP  NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `boatOwnerId` (`boatOwnerId`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE Preferences
  ADD FOREIGN KEY (`boatOwnerId`) REFERENCES BoatOwner (`id`);

ALTER TABLE Preferences
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  ADD UNIQUE INDEX uuid_idx (`uuid`);

DROP TABLE IF EXISTS CommunicationTypePreference;
CREATE TABLE IF NOT EXISTS CommunicationTypePreference (
  `id`          BIGINT       NOT NULL     AUTO_INCREMENT,
  `uuid`        BINARY(36)   NOT NULL,
  `title`       VARCHAR(10)  NOT NULL,
  `description` VARCHAR(255) NOT NULL,
  `valid`       TINYINT(1)   NOT NULL     DEFAULT 1,
  `lastAccess`  TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`     TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE CommunicationTypePreference
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  ADD UNIQUE INDEX uuid_idx (`uuid`);

INSERT INTO CommunicationTypePreference
SET uuid = UUID(), title = "App", description = "Recieve communications by App";
INSERT INTO CommunicationTypePreference
SET uuid = UUID(), title = "Email", description = "Recieve communications by email";
INSERT INTO CommunicationTypePreference
SET uuid = UUID(), title = "SMS", description = "Recieve communications by sms";

DROP TABLE IF EXISTS BoatOwnerCommunicationPreference;
CREATE TABLE IF NOT EXISTS BoatOwnerCommunicationPreference (
  `id`                        BIGINT     NOT NULL     AUTO_INCREMENT,
  `boatOwnerId`               BIGINT     NOT NULL,
  `communicationPreferenceId` BIGINT     NOT NULL,
  `valid`                     TINYINT(1) NULL         DEFAULT 1,
  `lastAccess`                TIMESTAMP  NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`                   TIMESTAMP  NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `boatOwnerId` (`boatOwnerId`),
  CONSTRAINT `boatOwnerId_compref_fk` FOREIGN KEY (`boatOwnerId`) REFERENCES `BoatOwner` (`id`),
  CONSTRAINT `commPref_commPref_fk` FOREIGN KEY (`communicationPreferenceId`) REFERENCES `CommunicationTypePreference` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE BoatOwnerCommunicationPreference
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP FOREIGN KEY boatOwnerId_compref_fk,
  DROP FOREIGN KEY commPref_commPref_fk,
  DROP INDEX boatOwnerId,
  ADD FOREIGN KEY boatowner_fk (boatOwnerId) REFERENCES BoatOwner (`id`),
  ADD FOREIGN KEY commpref_fk (communicationPreferenceId) REFERENCES CommunicationTypePreference (`id`);

DROP TABLE IF EXISTS BoatOwnerIssue;
CREATE TABLE IF NOT EXISTS BoatOwnerIssue (
  `id`          BIGINT     NOT NULL     AUTO_INCREMENT,
  `issueUuid`   BINARY(36) NOT NULL,
  `boatOwnerId` BIGINT     NOT NULL,
  `valid`       TINYINT(1) NOT NULL     DEFAULT 1,
  `lastAccess`  TIMESTAMP  NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`     TIMESTAMP  NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `boatOwnerId` (`boatOwnerId`)

)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE BoatOwnerIssue
  ADD FOREIGN KEY (`boatOwnerId`) REFERENCES BoatOwner (`id`);

ALTER TABLE BoatOwnerIssue
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP KEY boatOwnerId,
  ADD INDEX boatowner_idx (boatOwnerId),
  ADD FOREIGN KEY boatowner_fk (boatOwnerId) REFERENCES BoatOwner (`id`);


DROP TABLE IF EXISTS MaintenanceReps;

CREATE TABLE IF NOT EXISTS MaintenanceReps (
  `id`                 BIGINT     NOT NULL     AUTO_INCREMENT,
  `maintenanceRepUuid` BINARY(36) NOT NULL,
  `boatOwnerId`        BIGINT     NOT NULL,
  `valid`              TINYINT(1) NOT NULL     DEFAULT 1,
  `lastAccess`         TIMESTAMP  NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`            TIMESTAMP  NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `boatOwnerId` (`boatOwnerId`)

)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE MaintenanceReps
  ADD INDEX maintenancereps_idx (maintenanceRepUuid);

ALTER TABLE MaintenanceReps
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX boatOwnerId,
  ADD FOREIGN KEY boatowner_fk (boatOwnerId) REFERENCES BoatOwner (`id`);

DROP TABLE IF EXISTS BoatOwnerPreference;
CREATE TABLE IF NOT EXISTS BoatOwnerPreference (
  `id`               BIGINT       NOT NULL     AUTO_INCREMENT,
  `uuid`             BINARY(36)   NOT NULL,
  `title`            VARCHAR(255) NOT NULL,
  `shortDescription` VARCHAR(255) NOT NULL,
  `longDescription`  TEXT         NULL,
  `defaultState`     TINYINT(1)   NOT NULL,
  `defaultValue`     TEXT         NOT NULL,
  `enum`             VARCHAR(255) NOT NULL,
  `isAlertRelevant`  TINYINT(1)   NOT NULL     DEFAULT 0,
  `alertUuid`        BINARY(36)   NULL,
  `valid`            TINYINT(1)   NOT NULL     DEFAULT 1,
  `lastAccess`       TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`          TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid_bop` (`uuid`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE BoatOwnerPreference
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX uuid_bop,
  ADD UNIQUE INDEX uuid_idx (`uuid`);

DROP TABLE IF EXISTS BoatOwnerBoatOwnerPreference;
CREATE TABLE IF NOT EXISTS BoatOwnerBoatOwnerPreference (
  `id`                    BIGINT     NOT NULL     AUTO_INCREMENT,
  `uuid`                  BINARY(36) NOT NULL,
  `boatOwnerId`           BIGINT     NOT NULL,
  `boatOwnerPreferenceId` BIGINT     NOT NULL,
  `state`                 TINYINT(1) NOT NULL,
  `value`                 TEXT       NOT NULL,
  `valid`                 TINYINT(1) NOT NULL     DEFAULT 1,
  `lastAccess`            TIMESTAMP  NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`               TIMESTAMP  NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid_boprf` (`uuid`),
  INDEX `boatOwnerId_preference` (`boatOwnerId`),
  CONSTRAINT `boatOwnerId_bop_fk` FOREIGN KEY (`boatOwnerId`) REFERENCES `BoatOwner` (`id`),
  CONSTRAINT `boatOwnerPreferenceId_bop_fk` FOREIGN KEY (`boatOwnerPreferenceId`) REFERENCES `BoatOwnerPreference` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE MaintenanceReps
  ADD FOREIGN KEY (`boatOwnerId`) REFERENCES BoatOwner (`id`);

ALTER TABLE BoatOwnerBoatOwnerPreference
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP FOREIGN KEY boatOwnerId_bop_fk,
  DROP FOREIGN KEY boatOwnerPreferenceId_bop_fk,
  DROP INDEX uuid_boprf,
  DROP INDEX `boatOwnerId_preference`,
  ADD UNIQUE INDEX uuid_idx (`uuid`),
  ADD FOREIGN KEY boatownerpref_fk (boatOwnerPreferenceId) REFERENCES BoatOwnerPreference (`id`),
  ADD FOREIGN KEY boatowner_fk (boatOwnerId) REFERENCES BoatOwner (`id`);

DROP TABLE IF EXISTS BoatOwnerDealer;
CREATE TABLE IF NOT EXISTS BoatOwnerDealer (
  `id`          BIGINT     NOT NULL     AUTO_INCREMENT,
  `dealerUuid`  BINARY(36) NOT NULL,
  `boatOwnerId` BIGINT     NOT NULL,
  `valid`       TINYINT(1) NOT NULL     DEFAULT 1,
  `lastAccess`  TIMESTAMP  NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`     TIMESTAMP  NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `boatOwnerId` (`boatOwnerId`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE BoatOwnerDealer
  ADD INDEX dealeruuid_idx (dealerUuid);

ALTER TABLE BoatOwnerDealer
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX boatOwnerId,
  ADD FOREIGN KEY boatowner_fk (boatOwnerId) REFERENCES BoatOwner (`id`);

DROP TABLE IF EXISTS BoatOwnerPuckExclusionPreference;
CREATE TABLE IF NOT EXISTS BoatOwnerPuckExclusionPreference (
  `id`                  BIGINT        NOT NULL AUTO_INCREMENT,
  `uuid`                BINARY(36)    NOT NULL,
  `dealerUuid`          BINARY(36)    NOT NULL,
  `maintenanceRepUuid`  BINARY(36)    NOT NULL,
  `puckId`              VARCHAR(255)  NOT NULL,
  `boatOwnerId`         BIGINT        NOT NULL,
  `valid`               TINYINT(1)    NOT NULL DEFAULT 1,
  `lastAccess`          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`             TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid_bopep` (`uuid`),
  INDEX `dealerUuid_bopep` (`dealerUuid`),
  INDEX `boatOwnerId` (`boatOwnerId`),
  CONSTRAINT `boatOwnerId_bopep_fk` FOREIGN KEY (`boatOwnerId`) REFERENCES `BoatOwner` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE BoatOwnerBoatOwnerPreference ADD `puckId` VARCHAR(255) NULL;
ALTER TABLE BoatOwnerBoatOwnerPreference ADD `networkId` VARCHAR(255) NULL;


DROP DATABASE IF EXISTS CV_Boat;
CREATE SCHEMA IF NOT EXISTS CV_Boat
  DEFAULT CHARACTER SET utf8
  COLLATE utf8_general_ci;
USE CV_Boat;

ALTER DATABASE
CHARACTER SET utf8mb4
COLLATE utf8mb4_general_ci;

DROP TABLE IF EXISTS Authorization;
CREATE TABLE IF NOT EXISTS Authorization (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `serviceName` VARCHAR(255) NOT NULL,
  `key`         VARCHAR(255) NOT NULL,
  `secret`      VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

-- this doesn't need to be utf8
ALTER TABLE Authorization
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

-- should move this to separate file to customize per environment
INSERT INTO Authorization (`serviceName`, `key`, `secret`) VALUES ('testService', 'key', SHA2('secret', 256));

DROP TABLE IF EXISTS BoatBrand;
CREATE TABLE IF NOT EXISTS BoatBrand (
  `id`           BIGINT       NOT NULL AUTO_INCREMENT,
  `uuid`         BINARY(36)   NOT NULL,
  `name`         VARCHAR(512) NOT NULL,
  `oemUuid`      BINARY(36)   NOT NULL,
  `brandLogoUrl` VARCHAR(255) NULL,
  `url`          VARCHAR(255) NULL,
  `description`  TEXT         NULL,
  `mic`          VARCHAR(3)   NOT NULL,
  `valid`        TINYINT(1)   NOT NULL DEFAULT 1,
  `lastAccess`   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid` (`uuid`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

CREATE FULLTEXT INDEX brand_name_idx
  ON BoatBrand (name);

ALTER TABLE BoatBrand
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX `uuid`,
  ADD UNIQUE INDEX `uuid_idx` (`uuid`, `valid`),
  ADD INDEX mic_idx (mic);

DROP TABLE IF EXISTS BoatZone;
CREATE TABLE IF NOT EXISTS BoatZone (
  `id`               BIGINT     NOT NULL AUTO_INCREMENT,
  `uuid`             BINARY(36) NOT NULL,
  `numberOfZones`    INT        NOT NULL,
  `numberVertical`   INT        NOT NULL,
  `numberHorizontal` INT        NOT NULL,
  `valid`            TINYINT(1) NOT NULL DEFAULT 1,
  `lastAccess`       TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`          TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid` (`uuid`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE BoatZone
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX `uuid`,
  ADD UNIQUE INDEX uuid_idx (`uuid`, `valid`);

DROP TABLE IF EXISTS BoatModel;
CREATE TABLE IF NOT EXISTS BoatModel (
  `id`                      BIGINT            NOT NULL AUTO_INCREMENT,
  `uuid`                    BINARY(36)        NOT NULL,
  `boatBrandId`             BIGINT            NULL,
  `startYear`               SMALLINT UNSIGNED NOT NULL,
  `modelName`               VARCHAR(255)      NOT NULL,
  `modelImageUrl`           VARCHAR(255)      NULL,
  `endYear`                 SMALLINT UNSIGNED NOT NULL,
  `numberOfVerticalZones`   SMALLINT UNSIGNED NOT NULL,
  `numberOfHorizontalZones` SMALLINT UNSIGNED NOT NULL,
  `length`                  INT UNSIGNED      NOT NULL,
  `manual`                  VARCHAR(512) CHARACTER SET "ascii"
  COLLATE "ascii_general_ci"                  NULL,
  `boatZoneId`              BIGINT            NULL,
  `valid`                   TINYINT(1)        NOT NULL DEFAULT 1,
  `description`             TEXT              NOT NULL,
  `lastAccess`              TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`                 TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid` (`uuid`),
  CONSTRAINT `boatBrandId_BoatModel_fk` FOREIGN KEY (`boatBrandId`) REFERENCES `BoatBrand` (`id`),
  CONSTRAINT `boatZoneId_BoatModel_fk` FOREIGN KEY (`boatZoneId`) REFERENCES `BoatZone` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE BoatModel
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX `uuid`,
  ADD UNIQUE INDEX uuid_idx (`uuid`);

DROP TABLE IF EXISTS ModelBaseComponents;
CREATE TABLE IF NOT EXISTS ModelBaseComponents (
  `id`            BIGINT     NOT NULL AUTO_INCREMENT,
  `boatModelId`   BIGINT     NOT NULL,
  `componentUuid` BINARY(36) NOT NULL,
  `created`       TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastAccess`    TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `valid`         TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  INDEX `Id` (`boatModelId`),
  CONSTRAINT `boatModelId_ModelBaseComponents_fk` FOREIGN KEY (`boatModelId`) REFERENCES `BoatModel` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE ModelBaseComponents
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  ADD INDEX component_idx (componentUuid);

DROP TABLE IF EXISTS Boat;
CREATE TABLE IF NOT EXISTS Boat (
  `id`              BIGINT            NOT NULL AUTO_INCREMENT,
  `uuid`            BINARY(36)        NOT NULL,
  `boatModelId`     BIGINT            NULL,
  `boatBrandId`     BIGINT            NULL,
  `year`            SMALLINT UNSIGNED NULL,
  `serial`          VARCHAR(20)       NULL,
  `hin`             VARCHAR(20)       NULL,
  `name`            VARCHAR(255)      NULL,
  `customBrandName` VARCHAR(255)      NULL,
  `customModelName` VARCHAR(255)      NULL,
  `boatImageUrl`    VARCHAR(255)      NULL,
  `lastServiceDate` BIGINT            NULL,
  `componentData`   JSON              NULL,
  `valid`           TINYINT(1)        NOT NULL DEFAULT 1,
  `created`         TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastAccess`      TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid` (`uuid`),
  CONSTRAINT `boatmodelId_boat_fk` FOREIGN KEY (`boatModelId`) REFERENCES `BoatModel` (`id`),
  CONSTRAINT `boatBrandId_boat_fk` FOREIGN KEY (`boatBrandId`) REFERENCES `BoatBrand` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE Boat
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX `uuid`,
  ADD UNIQUE INDEX uuid_idx (`uuid`),
  ADD INDEX hin_idx (hin);


DROP TABLE IF EXISTS BoatComponent;
CREATE TABLE IF NOT EXISTS BoatComponent (
  `id`                BIGINT     NOT NULL AUTO_INCREMENT,
  `boatId`            BIGINT     NOT NULL,
  `componentUuid`     BINARY(36) NOT NULL,
  `modificationNotes` TEXT       NULL,
  `comments`          TEXT       NULL,
  `installDate`       DATE       NULL,
  `valid`             TINYINT(1) NOT NULL DEFAULT 1,
  `created`           TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastAccess`        TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `boatId` (`boatId`),
  CONSTRAINT `boatId_components_fk` FOREIGN KEY (`boatId`) REFERENCES `Boat` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE BoatComponent
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  ADD INDEX component_idx (componentUuid);

DROP TABLE IF EXISTS BoatServiceRecords;
CREATE TABLE IF NOT EXISTS BoatServiceRecords (
  `id`                 BIGINT       NOT NULL AUTO_INCREMENT,
  `uuid`               BINARY(36)   NOT NULL,
  `boatId`             BIGINT       NOT NULL,
  `dateInitiated`      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description`        TEXT         NOT NULL,
  `title`              VARCHAR(255) NOT NULL,
  `dateCompleted`      TIMESTAMP    NULL,
  `componentUuid`      BINARY(36)   NOT NULL,
  `dealerUuid`         BINARY(36)   NOT NULL,
  `maintenanceRepUuid` BINARY(36)   NOT NULL,
  `issueUuid`          BINARY(36)   NOT NULL,
  `valid`              TINYINT(1)   NOT NULL DEFAULT 1,
  `created`            TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastAccess`         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid` (`uuid`),
  CONSTRAINT `boatId_BoatServiceRecords_fk` FOREIGN KEY (`boatId`) REFERENCES `Boat` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE BoatServiceRecords
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX `uuid`,
  ADD UNIQUE INDEX uuid_idx (`uuid`);


DROP TABLE IF EXISTS BoatNetwork;
CREATE TABLE IF NOT EXISTS BoatNetwork (
  `id`         BIGINT      NOT NULL AUTO_INCREMENT,
  `boatId`     BIGINT      NOT NULL,
  `networkId`  VARCHAR(36) NOT NULL,
  `valid`      TINYINT(1)  NOT NULL DEFAULT 1,
  `created`    TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastAccess` TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (`id`),
  INDEX `networkId` (`networkId`),
  CONSTRAINT `boatLinkId_boat_fk` FOREIGN KEY (`boatId`) REFERENCES `Boat` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE BoatNetwork
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

ALTER TABLE Boat ADD `externalRefId` VARCHAR(255) NULL;
ALTER TABLE Boat ADD `extendedService` VARCHAR(255) NULL;
ALTER TABLE Boat ADD `isFactoryInstalled` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE Boat ADD `sellingDealerUuid` BINARY(36) NULL;
ALTER TABLE BoatBrand ADD `factoryInstall` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE BoatModel ADD `factoryInstall` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE Boat ADD `hull` VARCHAR(20) NULL;
ALTER TABLE Boat ADD `isInstallCompleted` TINYINT(1) NOT NULL DEFAULT 0;
UPDATE Boat set isInstallCompleted = 1;

ALTER TABLE Boat ADD `initialSync` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE Boat ADD `lastSyncTime` DATETIME NULL DEFAULT NULL; 

DROP DATABASE IF EXISTS CV_Command;
CREATE SCHEMA IF NOT EXISTS CV_Command
  DEFAULT CHARACTER SET utf8
  COLLATE utf8_general_ci;
USE CV_Command;

DROP TABLE IF EXISTS Authorization;

CREATE TABLE IF NOT EXISTS Authorization (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `serviceName` VARCHAR(255) NOT NULL,
  `key`         VARCHAR(255) NOT NULL,
  `secret`      VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET=latin1;

INSERT INTO Authorization (`serviceName`, `key`, `secret`) VALUES ('testService', 'key', SHA2('secret', 256));

DROP TABLE IF EXISTS Command;
CREATE TABLE IF NOT EXISTS Command (
  `id`                BIGINT       NOT NULL AUTO_INCREMENT,
  `uuid`              BINARY(36)   NOT NULL,
  `deviceTypeId`      VARCHAR(255)   NULL,
  `name`              VARCHAR(255) NOT NULL,
  `title`             VARCHAR(255) NOT NULL,
  `shortDescription`  VARCHAR(512) NULL,
  `longDescription`   TEXT NULL,
  `actionText`        TEXT NULL,
  `hasAdditionalFields` TINYINT(1) NOT NULL DEFAULT 0,  
  `valid`             TINYINT(1) NOT NULL DEFAULT 1,
  `lastAccess`        TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`           TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid` (`uuid`)
)ENGINE = InnoDB, DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS Field;
CREATE TABLE IF NOT EXISTS Field (
  `id`                BIGINT       NOT NULL AUTO_INCREMENT,
  `commandId`         BIGINT   NOT NULL,
  `variableName`      VARCHAR(255) NOT NULL,
  `title`             VARCHAR(255) NOT NULL,
  `shortDescription`  VARCHAR(512) NULL,
  `longDescription`   TEXT NULL,
  `actionText`        TEXT NULL,
  `valid`             TINYINT(1) NOT NULL DEFAULT 1,
  `lastAccess`        TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`           TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `command_field_fk` FOREIGN KEY (`commandId`) REFERENCES `Command` (`id`)
)ENGINE = InnoDB, DEFAULT CHARSET=latin1;

-- INSERT INTO Command SET uuid='b3c70e25-ecb1-49e0-a209-bbd5aa583794', name='RELAY_OPEN', title="Turn Relay Off";
-- INSERT INTO Command SET uuid='b3c70e25-ecb1-49e0-a209-bbd5aa583795', name='RELAY_CLOSE', title="Turn Relay On";

-- INSERT INTO Command SET uuid='b3c70e25-ecb1-49e0-a209-bbd5aa583796', name='HVAC_SET_TEMP', title="Set HVAC Temperature", hasAdditionalFields=1;
-- INSERT INTO Field SET commandId=3, variableName='setPointTemperature', title="HVAC Setpoint Temperature";

DROP DATABASE IF EXISTS CV_Component;
CREATE SCHEMA IF NOT EXISTS CV_Component
  DEFAULT CHARACTER SET utf8
  COLLATE utf8_general_ci;
USE CV_Component;

ALTER DATABASE CHARACTER SET utf8mb4
COLLATE utf8mb4_general_ci;

DROP TABLE IF EXISTS Authorization;
CREATE TABLE IF NOT EXISTS Authorization (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `serviceName` VARCHAR(255) NOT NULL,
  `key`         VARCHAR(255) NOT NULL,
  `secret`      VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

INSERT INTO Authorization (`serviceName`, `key`, `secret`) VALUES ('testService', 'key', SHA2('secret', 256));

ALTER TABLE Authorization
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

DROP TABLE IF EXISTS EngineInfo;
CREATE TABLE IF NOT EXISTS EngineInfo (
  `id`                 BIGINT       NOT NULL     AUTO_INCREMENT,
  `uuid`               BINARY(36)   NOT NULL,
  `horsePower`         INTEGER      NOT NULL,
  `recommendedOilType` VARCHAR(255) NOT NULL,
  `manualUrl`          TEXT         NULL,
  `ratedFuelEconomy`   INTEGER      NOT NULL,
  `calibration`        VARCHAR(255) NULL,
  `softwareVersion`    VARCHAR(255) NULL,
  `runtime`            VARCHAR(255) NULL,
  `size`               VARCHAR(10)  NULL,
  `valid`              TINYINT(1)   NOT NULL     DEFAULT 1,
  `lastAccess`         TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`            TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid` (`uuid`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE EngineInfo
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX `uuid`,
  ADD UNIQUE INDEX uuid_idx (`uuid`);

DROP TABLE IF EXISTS ElectricalInfo;
CREATE TABLE IF NOT EXISTS ElectricalInfo (
  `id`            BIGINT         NOT NULL     AUTO_INCREMENT,
  `uuid`          BINARY(36)     NOT NULL,
  `maxVoltage`    DECIMAL(10, 2) NULL,
  `minVoltage`    DECIMAL(10, 2) NULL,
  `maxPower`      DECIMAL(10, 2) NULL,
  `maxCurrent`    DECIMAL(10, 2) NULL,
  `minCurrent`    DECIMAL(10, 2) NULL,
  `currentRating` DECIMAL(10, 2) NULL,
  `averagePower`  DECIMAL(10, 2) NULL,
  `ratedPower`    DECIMAL(10, 2) NULL,
  `ac`            TINYINT(1)     NOT NULL     DEFAULT 0,
  `dc`            TINYINT(1)     NOT NULL     DEFAULT 1,
  `valid`         TINYINT(1)     NOT NULL     DEFAULT 1,
  `lastAccess`    TIMESTAMP      NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`       TIMESTAMP      NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid` (`uuid`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE ElectricalInfo
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX `uuid`,
  ADD UNIQUE INDEX uuid_idx (`uuid`);

DROP TABLE IF EXISTS ComponentType;
CREATE TABLE IF NOT EXISTS ComponentType (
  `id`               BIGINT       NOT NULL     AUTO_INCREMENT,
  `uuid`             BINARY(36)   NOT NULL,
  `name`             VARCHAR(255) NOT NULL,
  `title`            VARCHAR(255) NOT NULL,
  `shortDescription` TEXT         NULL,
  `longDescription`  TEXT         NULL,
  `valid`            TINYINT(1)   NOT NULL     DEFAULT 1,
  `lastAccess`       TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`          TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid` (`uuid`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE ComponentType
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX `uuid`,
  ADD UNIQUE INDEX uuid_idx (`uuid`);

INSERT INTO ComponentType SET uuid=UUID(), name='BILGE', title='Bilge Pump';
INSERT INTO ComponentType SET uuid=UUID(), name='ENGINE', title='Engine';
INSERT INTO ComponentType SET uuid=UUID(), name='REFRIGERATOR', title='Refrigerator';
INSERT INTO ComponentType SET uuid=UUID(), name='HELM_SYSTEM', title='Helm System';
INSERT INTO ComponentType SET uuid=UUID(), name='BATTERY', title='Battery';
INSERT INTO ComponentType SET uuid=UUID(), name='GENERATOR', title='Genset';
INSERT INTO ComponentType SET uuid=UUID(), name='MOTION_SENSOR', title='Motion Sensor';
INSERT INTO ComponentType SET uuid=UUID(), name='CAMERA', title='Camera';
INSERT INTO ComponentType SET uuid=UUID(), name='TEMPERATURE', title='Temperature';
INSERT INTO ComponentType SET uuid=UUID(), name='HUMIDITY', title='Humidity';
INSERT INTO ComponentType SET uuid=UUID(), name='SHOREPOWER', title='Shorepower';
INSERT INTO ComponentType SET uuid=UUID(), name='GPS', title='GPS';

DROP TABLE IF EXISTS Component;
CREATE TABLE IF NOT EXISTS Component (
  `id`               BIGINT       NOT NULL     AUTO_INCREMENT,
  `uuid`             BINARY(36)   NOT NULL,
  `name`             VARCHAR(255) NOT NULL,
  `model`            VARCHAR(255) NOT NULL,
  `brand`            VARCHAR(255) NOT NULL,
  `year`             INTEGER      NOT NULL,
  `componentTypeId`  BIGINT       NOT NULL,
  `electricalInfoId` BIGINT       NULL,
  `engineInfoId`     BIGINT       NULL,
  `width`            DECIMAL      NULL,
  `height`           DECIMAL      NULL,
  `length`           DECIMAL      NULL,
  `dataId`           VARCHAR(255) NULL,
  `nmeaCode`         VARCHAR(255) NULL,
  `url`              TEXT         NULL,
  `manualUrl`        TEXT         NULL,
  `valid`            TINYINT(1)   NOT NULL     DEFAULT 1,
  `lastAccess`       TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`          TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `component_engineInfo_fk` FOREIGN KEY (`engineInfoId`) REFERENCES `EngineInfo` (`id`),
  CONSTRAINT `component_electricalInfo_fk` FOREIGN KEY (`electricalInfoId`) REFERENCES `ElectricalInfo` (`id`),
  CONSTRAINT `component_componentType_fk` FOREIGN KEY (`componentTypeId`) REFERENCES `ComponentType` (`id`),
  INDEX `uuid` (`uuid`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE Component
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX `uuid`,
  ADD INDEX uuid_idx (`uuid`);



DROP DATABASE IF EXISTS CV_Email;
CREATE SCHEMA IF NOT EXISTS CV_Email
  DEFAULT CHARACTER SET utf8
  COLLATE utf8_general_ci;
USE CV_Email;

DROP TABLE IF EXISTS Authorization;

CREATE TABLE IF NOT EXISTS Authorization (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `serviceName` VARCHAR(255) NOT NULL,
  `key`         VARCHAR(255) NOT NULL,
  `secret`      VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET=latin1;

INSERT INTO Authorization (`serviceName`, `key`, `secret`) VALUES ('testService', 'key', SHA2('secret', 256));

DROP TABLE IF EXISTS Email;
CREATE TABLE IF NOT EXISTS Email ( 
  `id`      	      BIGINT     		NOT NULL AUTO_INCREMENT,
  `uuid`    	      BINARY(36)		NOT NULL,
  `template`        VARCHAR(255)  NOT NULL,
  `recipientEmail`  BINARY(36) 	NOT NULL,
  `userUuid`    	  BINARY(36)  NOT NULL,
  `message`         TEXT NULL,
  `valid`   	      TINYINT(1) 		NOT NULL DEFAULT 1,
  `lastAccess` 	    TIMESTAMP      	NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`         TIMESTAMP      	NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
)ENGINE = InnoDB, DEFAULT CHARSET=latin1;


DROP DATABASE IF EXISTS CV_Geolocation;
CREATE SCHEMA IF NOT EXISTS CV_Geolocation
  DEFAULT CHARACTER SET utf8
  COLLATE utf8_general_ci;
USE CV_Geolocation;

DROP TABLE IF EXISTS Authorization;

CREATE TABLE IF NOT EXISTS Authorization (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `serviceName` VARCHAR(255) NOT NULL,
  `key`         VARCHAR(255) NOT NULL,
  `secret`      VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET=latin1;

INSERT INTO Authorization (`serviceName`, `key`, `secret`) VALUES ('testService', 'key', SHA2('secret', 256));

DROP TABLE IF EXISTS GeolocationCacheRecord;
CREATE TABLE IF NOT EXISTS GeolocationCacheRecord (
  `id`                BIGINT       NOT NULL AUTO_INCREMENT,
  `uuid`              BINARY(36)   NULL,
  `latitude`              VARCHAR(255) NOT NULL,
  `longitude`             VARCHAR(255) NOT NULL,
  `data`              JSON NULL,
  `valid`             TINYINT(1) NOT NULL DEFAULT 1,
  `lastAccess`        TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`           TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid` (`uuid`)
)ENGINE = InnoDB, DEFAULT CHARSET=latin1;


#
# Copyright (c) 2015 - 2017. Technicity LLC. All rights reserved.
#
DROP DATABASE IF EXISTS `CV_Link`;
CREATE SCHEMA IF NOT EXISTS `CV_Link`
  DEFAULT CHARACTER SET utf8
  COLLATE utf8_general_ci;
USE `CV_Link`;

-- -----------------------------------------------------
-- Table `Authorization`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Authorization`;

CREATE TABLE IF NOT EXISTS `Authorization` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `serviceName` VARCHAR(255) NOT NULL,
  `key`         VARCHAR(255) NOT NULL,
  `secret`      VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB;

INSERT INTO Authorization (`serviceName`, `key`, `secret`) VALUES ('testService', 'key', SHA2('secret', 256));


DROP TABLE IF EXISTS `BoatOwnerDealer`;
CREATE TABLE IF NOT EXISTS `BoatOwnerDealer` (
  `id`          BIGINT NOT NULL AUTO_INCREMENT,
  `boatOwnerUuid`     BINARY(36) NOT NULL,
  `dealerUuid`     BINARY(36) NOT NULL,
  `expires`     BIGINT NULL,
  `valid`              TINYINT(1)   	NOT NULL DEFAULT 1,
  `lastAccess`         TIMESTAMP    	NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`            TIMESTAMP    	NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `boatOwnerdealer_idx` (`boatOwnerUuid`),
  INDEX `dealerboatOwner_idx` (`dealerUuid`)
) ENGINE = InnoDB;

DROP TABLE IF EXISTS `BoatDealer`;
CREATE TABLE IF NOT EXISTS `BoatDealer` (
  `id`          BIGINT NOT NULL AUTO_INCREMENT,
  `boatUuid`     BINARY(36) NOT NULL,
  `dealerUuid`     BINARY(36) NOT NULL,
  `expires`     BIGINT NULL,
  `valid`              TINYINT(1)   	NOT NULL DEFAULT 1,
  `lastAccess`         TIMESTAMP    	NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`            TIMESTAMP    	NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `boatdealer_idx` (`boatUuid`),
  INDEX `dealerboat_idx` (`dealerUuid`)
) ENGINE = InnoDB;


DROP TABLE IF EXISTS `MaintenanceRepDealer`;
CREATE TABLE IF NOT EXISTS `MaintenanceRepDealer` (
  `id`          BIGINT NOT NULL AUTO_INCREMENT,
  `maintenanceRepUuid`     BINARY(36) NOT NULL,
  `dealerUuid`     BINARY(36) NOT NULL,
  `expires`     BIGINT NULL,
  `valid`              TINYINT(1)   	NOT NULL DEFAULT 1,
  `lastAccess`         TIMESTAMP    	NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`            TIMESTAMP    	NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `maintenanceRepdealer_idx` (`maintenanceRepUuid`),
  INDEX `dealermaintenanceRep_idx` (`dealerUuid`)
) ENGINE = InnoDB;


DROP TABLE IF EXISTS `OemRepOem`;
CREATE TABLE IF NOT EXISTS `OemRepOem` (
  `id`          BIGINT NOT NULL AUTO_INCREMENT,
  `oemRepUuid`     BINARY(36) NOT NULL,
  `oemUuid`     BINARY(36) NOT NULL,
  `expires`     BIGINT NULL,
  `valid`              TINYINT(1)   	NOT NULL DEFAULT 1,
  `lastAccess`         TIMESTAMP    	NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`            TIMESTAMP    	NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `oemRepoem_idx` (`oemRepUuid`),
  INDEX `oemoemRep_idx` (`oemUuid`)
) ENGINE = InnoDB;


DROP TABLE IF EXISTS `OemDealer`;
CREATE TABLE IF NOT EXISTS `OemDealer` (
  `id`          BIGINT NOT NULL AUTO_INCREMENT,
  `oemUuid`     BINARY(36) NOT NULL,
  `dealerUuid`     BINARY(36) NOT NULL,
  `expires`     BIGINT NULL,
  `valid`              TINYINT(1)   	NOT NULL DEFAULT 1,
  `lastAccess`         TIMESTAMP    	NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`            TIMESTAMP    	NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `oemdealer_idx` (`oemUuid`),
  INDEX `dealeroem_idx` (`dealerUuid`)
) ENGINE = InnoDB;


DROP TABLE IF EXISTS `BoatOem`;
CREATE TABLE IF NOT EXISTS `BoatOem` (
  `id`          BIGINT NOT NULL AUTO_INCREMENT,
  `boatUuid`     BINARY(36) NOT NULL,
  `oemUuid`     BINARY(36) NOT NULL,
  `expires`     BIGINT NULL,
  `valid`              TINYINT(1)   	NOT NULL DEFAULT 1,
  `lastAccess`         TIMESTAMP    	NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`            TIMESTAMP    	NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `boatoem_idx` (`boatUuid`),
  INDEX `oemboat_idx` (`oemUuid`)
) ENGINE = InnoDB;


DROP TABLE IF EXISTS `BoatOwnerOem`;
CREATE TABLE IF NOT EXISTS `BoatOwnerOem` (
  `id`          BIGINT NOT NULL AUTO_INCREMENT,
  `boatOwnerUuid`     BINARY(36) NOT NULL,
  `oemUuid`     BINARY(36) NOT NULL,
  `expires`     BIGINT NULL,
  `valid`              TINYINT(1)   	NOT NULL DEFAULT 1,
  `lastAccess`         TIMESTAMP    	NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`            TIMESTAMP    	NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `boatOwneroem_idx` (`boatOwnerUuid`),
  INDEX `oemboatOwner_idx` (`oemUuid`)
) ENGINE = InnoDB;

DROP TABLE IF EXISTS `MediaIssue`;
CREATE TABLE IF NOT EXISTS `MediaIssue` (
  `id`          BIGINT NOT NULL AUTO_INCREMENT,
  `mediaUuid`     BINARY(36) NOT NULL,
  `issueUuid`     BINARY(36) NOT NULL,
  `expires`     BIGINT NULL,
  `valid`              TINYINT(1)   	NOT NULL DEFAULT 1,
  `uploaded`              TINYINT(1)   	NOT NULL DEFAULT 0,
  `lastAccess`         TIMESTAMP    	NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`            TIMESTAMP    	NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `mediaissue_idx` (`mediaUuid`),
  INDEX `issuemedia_idx` (`issueUuid`)
) ENGINE = InnoDB;

DROP TABLE IF EXISTS `MediaAlert`;
CREATE TABLE IF NOT EXISTS `MediaAlert` (
  `id`          BIGINT NOT NULL AUTO_INCREMENT,
  `mediaUuid`     BINARY(36) NOT NULL,
  `alertId`     VARCHAR(255) NOT NULL,
  `expires`     BIGINT NULL,
  `valid`              TINYINT(1)   	NOT NULL DEFAULT 1,
  `uploaded`              TINYINT(1)   	NOT NULL DEFAULT 0,
  `lastAccess`         TIMESTAMP    	NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`            TIMESTAMP    	NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `mediaalert_idx` (`mediaUuid`),
  INDEX `alertmedia_idx` (`alertId`)
) ENGINE = InnoDB;

DROP TABLE IF EXISTS `ServicePartnerDealer`;
CREATE TABLE IF NOT EXISTS `ServicePartnerDealer` (
  `id`          BIGINT NOT NULL AUTO_INCREMENT,
  `servicePartnerUuid`     BINARY(36) NOT NULL,
  `dealerUuid`     BINARY(36) NOT NULL,
  `expires`     BIGINT NULL,
  `valid`              TINYINT(1)   	NOT NULL DEFAULT 1,
  `lastAccess`         TIMESTAMP    	NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`            TIMESTAMP    	NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `servicePartnerdealer_idx` (`servicePartnerUuid`),
  INDEX `dealerservicePartner_idx` (`dealerUuid`)
) ENGINE = InnoDB;


DROP DATABASE IF EXISTS CV_Oem;
CREATE SCHEMA IF NOT EXISTS CV_Oem
  DEFAULT CHARACTER SET utf8
  COLLATE utf8_general_ci;
USE CV_Oem;

ALTER DATABASE CHARACTER SET utf8mb4
COLLATE utf8mb4_general_ci;

DROP TABLE IF EXISTS Authorization;

CREATE TABLE IF NOT EXISTS Authorization (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `serviceName` VARCHAR(255) NOT NULL,
  `key`         VARCHAR(255) NOT NULL,
  `secret`      VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = utf8;

ALTER TABLE Authorization
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

-- This should be moved to separate file
INSERT INTO Authorization (`serviceName`, `key`, `secret`) VALUES ('testService', 'key', SHA2('secret', 256));

DROP TABLE IF EXISTS Oem;
CREATE TABLE IF NOT EXISTS Oem (
  `id`                    BIGINT       NOT NULL     AUTO_INCREMENT,
  `uuid`                  BINARY(36)   NOT NULL,
  `name`                  VARCHAR(255) NOT NULL,
  `legalName`             VARCHAR(255) NULL,
  `primaryPhone`          VARCHAR(15)  NULL,
  `primaryPhoneExtension` VARCHAR(15)  NULL,
  `email`                 VARCHAR(255) NULL UNIQUE,
  `hasServiceAccount`     TINYINT(1)   NOT NULL     DEFAULT 0,
  `isVisible`             TINYINT(1)   NOT NULL     DEFAULT 1,
  `premiumServiceEnabled` TINYINT(1)   NOT NULL     DEFAULT 0,
  `logoUrl`               VARCHAR(512) CHARACTER SET "ascii"
  COLLATE "ascii_general_ci"           NULL,
  `bannerImageUrl`        VARCHAR(512) CHARACTER SET "ascii"
  COLLATE "ascii_general_ci"           NULL,
  `url`                   VARCHAR(512) CHARACTER SET "ascii"
  COLLATE "ascii_general_ci"           NULL,
  `valid`                 TINYINT(1)   NOT NULL     DEFAULT 1,
  `lastAccess`            TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`               TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid` (`uuid`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

DROP TABLE IF EXISTS OemRep;
CREATE TABLE IF NOT EXISTS OemRep (
  `id`             BIGINT       NOT NULL     AUTO_INCREMENT,
  `uuid`           BINARY(36)   NOT NULL,
  `userUuid`       BINARY(36)   NOT NULL,
  `preferredEmail` VARCHAR(255) NOT NULL UNIQUE,
  `preferredPhone` VARCHAR(20)  NULL,
  `preferredPhoneExtension` VARCHAR(15)  NULL,
  `valid`          TINYINT(1)   NOT NULL     DEFAULT 1,
  `lastAccess`     TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`        TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid_idx` (`uuid`),
  INDEX `user_uuid_idx` (`userUuid`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

DROP TABLE IF EXISTS Address;
CREATE TABLE IF NOT EXISTS Address (
  `id`         BIGINT       NOT NULL     AUTO_INCREMENT,
  `uuid`       BINARY(36)   NOT NULL,
  `oemId`      BIGINT       NOT NULL,
  `address1`   VARCHAR(512) NOT NULL,
  `address2`   VARCHAR(512) NULL,
  `city`       VARCHAR(256) NOT NULL,
  `state`      VARCHAR(256) NOT NULL,
  `zip`        VARCHAR(15)  NOT NULL,
  `isPrimary`  TINYINT(1)   NULL         DEFAULT 0,
  `latitude`   FLOAT(12, 8) NULL,
  `longitude`  FLOAT(12, 8) NULL,
  `valid`      TINYINT(1)   NOT NULL     DEFAULT 1,
  `created`    TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `lastAccess` TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `oemId` (`oemId`),
  INDEX `uuid_idx` (`uuid`),
  CONSTRAINT `oemId_address_fk` FOREIGN KEY (`oemId`) REFERENCES `Oem` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

DROP TABLE IF EXISTS OemOption;
CREATE TABLE IF NOT EXISTS OemOption (
  `id`               BIGINT       NOT NULL     AUTO_INCREMENT,
  `uuid`             BINARY(36)   NOT NULL,
  `oemId`            BIGINT       NOT NULL,
  `name`             VARCHAR(255) NOT NULL,
  `shortDescription` TEXT         NULL,
  `longDescription`  TEXT         NULL,
  `optionTypeEnum`   VARCHAR(255) NOT NULL,
  `metaData`         JSON         NULL,
  `active`           TINYINT(1)   NOT NULL     DEFAULT 1,
  `valid`            TINYINT(1)   NOT NULL     DEFAULT 1,
  `created`          TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `lastAccess`       TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `option_type_enum_idx` (`optionTypeEnum`),
  INDEX `option_uuid_idx` (`uuid`),
  CONSTRAINT `oemId_options_fk` FOREIGN KEY (`oemId`) REFERENCES `Oem` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

DROP DATABASE IF EXISTS CV_Rules;
CREATE SCHEMA IF NOT EXISTS CV_Rules
  DEFAULT CHARACTER SET utf8
  COLLATE utf8_general_ci;
USE CV_Rules;

DROP TABLE IF EXISTS Authorization;

CREATE TABLE IF NOT EXISTS Authorization (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `serviceName` VARCHAR(255) NOT NULL,
  `key`         VARCHAR(255) NOT NULL,
  `secret`      VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE Authorization
  CONVERT TO CHARACTER SET utf8
  COLLATE utf8_general_ci;

INSERT INTO Authorization (`serviceName`, `key`, `secret`) VALUES ('testService', 'key', SHA2('secret', 256));

DROP TABLE IF EXISTS Rule;
CREATE TABLE IF NOT EXISTS Rule (
  `id`                      BIGINT       NOT NULL AUTO_INCREMENT,
  `uuid`                    BINARY(36)   NOT NULL,
  `deviceTypeId`            VARCHAR(24)  NOT NULL,
  `deviceTypeName`          VARCHAR(255) NOT NULL,
  `dataVariableName`        VARCHAR(255) NOT NULL,
  `comparator`              VARCHAR(10)  NOT NULL,
  `valueOrSettingField`     VARCHAR(255) NOT NULL,
  `valueType`               VARCHAR(255) NOT NULL,
  `actionType`              VARCHAR(255) NOT NULL,
  `alertUuid`               BINARY(36)   NOT NULL,
  `alertDeterminationField` VARCHAR(255) NOT NULL,
  `function`                TEXT         NULL,
  `valid`                   TINYINT(1)   NOT NULL     DEFAULT 1,
  `lastAccess`              TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`                 TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE Rule
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  ADD UNIQUE INDEX uuid_idx (`uuid`);



DROP DATABASE IF EXISTS CV_Weather;
CREATE SCHEMA IF NOT EXISTS CV_Weather
  DEFAULT CHARACTER SET utf8
  COLLATE utf8_general_ci;
USE CV_Weather;

DROP TABLE IF EXISTS Authorization;

CREATE TABLE IF NOT EXISTS Authorization (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `serviceName` VARCHAR(255) NOT NULL,
  `key`         VARCHAR(255) NOT NULL,
  `secret`      VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET=latin1;

INSERT INTO Authorization (`serviceName`, `key`, `secret`) VALUES ('testService', 'key', SHA2('secret', 256));


DROP TABLE IF EXISTS WeatherCacheForCoordinates;
CREATE TABLE IF NOT EXISTS WeatherCacheForCoordinates (
  `id`                BIGINT       NOT NULL AUTO_INCREMENT,
  `latitude`          VARCHAR(255) NOT NULL,
  `longitude`         VARCHAR(255) NOT NULL,
  `data`              JSON NULL,
  `isAlert`           TINYINT NOT NULL DEFAULT 0,
  `isHighWind`        TINYINT NOT NULL DEFAULT 0,
  `timestamp`         BIGINT NOT NULL,
  `valid`             TINYINT(1) NOT NULL DEFAULT 1,
  `lastAccess`        TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`           TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
)ENGINE = InnoDB, DEFAULT CHARSET=latin1;

DROP DATABASE IF EXISTS CV_Dealer;
CREATE SCHEMA IF NOT EXISTS CV_Dealer
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;
USE CV_Dealer;

DROP TABLE IF EXISTS Authorization;

CREATE TABLE IF NOT EXISTS Authorization (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `serviceName` VARCHAR(255) NOT NULL,
  `key`         VARCHAR(255) NOT NULL,
  `secret`      VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE Authorization
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

INSERT INTO Authorization (`serviceName`, `key`, `secret`) VALUES ('testService', 'key', SHA2('secret', 256));

DROP TABLE IF EXISTS Dealer;
CREATE TABLE IF NOT EXISTS Dealer (
  `id`                    BIGINT       NOT NULL     AUTO_INCREMENT,
  `uuid`                  BINARY(36)   NOT NULL,
  `name`                  VARCHAR(255) NOT NULL,
  `legalName`             VARCHAR(255) NULL,
  `primaryPhone`          VARCHAR(15)  NULL,
  `primaryPhoneExtension` VARCHAR(15)  NULL,
  `email`                 VARCHAR(255) NULL UNIQUE,
  `hasServiceAccount`     TINYINT(1)   NOT NULL     DEFAULT 0,
  `isVisible`             TINYINT(1)   NOT NULL     DEFAULT 1,
  `premiumServiceEnabled` TINYINT(1)   NOT NULL     DEFAULT 0,
  `logoUrl`               VARCHAR(512) CHARACTER SET "ascii"
  COLLATE "ascii_general_ci"           NULL,
  `bannerImageUrl`        VARCHAR(512) CHARACTER SET "ascii"
  COLLATE "ascii_general_ci"           NULL,
  `url`                   VARCHAR(512) CHARACTER SET "ascii"
  COLLATE "ascii_general_ci"           NULL,
  `valid`                 TINYINT(1)   NOT NULL     DEFAULT 1,
  `lastAccess`            TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`               TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid` (`uuid`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE Dealer
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX uuid,
  ADD UNIQUE INDEX uuid_idx (uuid);

DROP TABLE IF EXISTS Address;
CREATE TABLE IF NOT EXISTS Address (
  `id`         BIGINT       NOT NULL     AUTO_INCREMENT,
  `uuid`       BINARY(36)   NOT NULL,
  `dealerId`   BIGINT       NOT NULL,
  `address1`   VARCHAR(512) NOT NULL,
  `address2`   VARCHAR(512) NULL,
  `city`       VARCHAR(256) NOT NULL,
  `state`      VARCHAR(256) NOT NULL,
  `zip`        VARCHAR(15)  NOT NULL,
  `isPrimary`  TINYINT(1)   NULL         DEFAULT 0,
  `latitude`   FLOAT(12, 8) NULL,
  `longitude`  FLOAT(12, 8) NULL,
  `valid`      TINYINT(1)   NOT NULL     DEFAULT 1,
  `created`    TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `lastAccess` TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `dealerId` (`dealerId`),
  CONSTRAINT `dealerId_address_fk` FOREIGN KEY (`dealerId`) REFERENCES `Dealer` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE Address
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  ADD UNIQUE INDEX uuid_idx (uuid);

DROP TABLE IF EXISTS DealerMaintenanceRep;
CREATE TABLE IF NOT EXISTS DealerMaintenanceRep (
  `id`                 BIGINT     NOT NULL AUTO_INCREMENT,
  `dealerId`           BIGINT     NOT NULL,
  `maintenanceRepUuid` BINARY(36) NOT NULL,
  `isPrimary`          TINYINT(1) NOT NULL     DEFAULT 0,
  `valid`              TINYINT(1) NOT NULL     DEFAULT 1,
  `created`            TIMESTAMP  NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `lastAccess`         TIMESTAMP  NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `dealerId` (`dealerId`),
  CONSTRAINT `dealerId_mrep_fk` FOREIGN KEY (`dealerId`) REFERENCES `Dealer` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE DealerMaintenanceRep
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

DROP TABLE IF EXISTS ServicePartner;
CREATE TABLE IF NOT EXISTS ServicePartner (
  `id`                       BIGINT       NOT NULL     AUTO_INCREMENT,
  `uuid`                     BINARY(36)   NOT NULL,
  `name`                     VARCHAR(255) NOT NULL,
  `legalName`                VARCHAR(255) NULL,
  `primaryPhone`             VARCHAR(15)  NULL,
  `primaryPhoneExtension`    VARCHAR(15)  NULL,
  `email`                    VARCHAR(255) NULL UNIQUE,
  `url`                      VARCHAR(512) CHARACTER SET "ascii"
  COLLATE "ascii_general_ci" NULL,
  `incidentNotificationUrl`  VARCHAR(512) CHARACTER SET "ascii"
  COLLATE "ascii_general_ci" NULL,
  `valid`                    TINYINT(1)   NOT NULL     DEFAULT 1,
  `created`                  TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `lastAccess`               TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `service_partner_uuid_idx` (`uuid`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

DROP TABLE IF EXISTS DealerBoat;
CREATE TABLE IF NOT EXISTS DealerBoat (
  `id`         BIGINT     NOT NULL AUTO_INCREMENT,
  `dealerId`   BIGINT     NOT NULL,
  `boatUuid`   BINARY(36) NOT NULL,
  `valid`      TINYINT(1) NOT NULL     DEFAULT 1,
  `created`    TIMESTAMP  NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `lastAccess` TIMESTAMP  NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `dealerId` (`dealerId`),
  CONSTRAINT `dealerId_boat_fk` FOREIGN KEY (`dealerId`) REFERENCES `Dealer` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE DealerBoat
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;


DROP TABLE IF EXISTS Picture;
CREATE TABLE IF NOT EXISTS Picture (
  `id`         BIGINT        NOT NULL AUTO_INCREMENT,
  `uuid`       BINARY(36)    NOT NULL,
  `url`        VARCHAR(512) CHARACTER SET "ascii"
  COLLATE "ascii_general_ci" NOT NULL,
  `caption`    TEXT          NULL,
  `dealerId`   BIGINT        NOT NULL,
  `valid`      TINYINT(1)    NOT NULL     DEFAULT 1,
  `created`    TIMESTAMP     NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `lastAccess` TIMESTAMP     NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid` (`id`),
  CONSTRAINT `dealerId_photos_fk` FOREIGN KEY (`dealerId`) REFERENCES `Dealer` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE Picture
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;


DROP TABLE IF EXISTS Hours;
CREATE TABLE IF NOT EXISTS Hours (
  `id`        BIGINT      NOT NULL AUTO_INCREMENT,
  `uuid`      BINARY(36)  NOT NULL,
  `dayOfWeek` VARCHAR(25) NOT NULL,
  `startHour` VARCHAR(25) NULL,
  `endHour`   VARCHAR(25) NULL,
  `dealerId`  BIGINT      NOT NULL,
  `valid`     TINYINT(1)  NOT NULL     DEFAULT 1,
  `created`   TIMESTAMP   NOT NULL     DEFAULT current_timestamp,
  PRIMARY KEY (`id`),
  INDEX `dealerId` (`dealerId`),
  CONSTRAINT `dealerId_hours_fk` FOREIGN KEY (`dealerId`) REFERENCES `Dealer` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE Hours
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  ADD UNIQUE INDEX uuid_idx (uuid);

DROP TABLE IF EXISTS Note;
CREATE TABLE IF NOT EXISTS Note (
  `id`            BIGINT     NOT NULL AUTO_INCREMENT,
  `uuid`          BINARY(36) NOT NULL,
  `boatOwnerUuid` BINARY(36) NOT NULL,
  `note`          TEXT       NULL,
  `dealerId`      BIGINT     NOT NULL,
  `valid`         TINYINT(1) NOT NULL     DEFAULT 1,
  `created`       TIMESTAMP  NOT NULL     DEFAULT current_timestamp,
  `lastAccess`    TIMESTAMP  NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `dealerId` (`dealerId`),
  CONSTRAINT `dealerId_note_fk` FOREIGN KEY (`dealerId`) REFERENCES `Dealer` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE Note
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  ADD UNIQUE INDEX uuid_idx (uuid);

DROP TABLE IF EXISTS DealerSubscription;
CREATE TABLE IF NOT EXISTS DealerSubscription (
  `id`                      BIGINT      NOT NULL AUTO_INCREMENT,
  `uuid`                    BINARY(36)  NOT NULL,
  `dealerId`                BIGINT      NOT NULL,
  `valid`                   TINYINT(1)  NOT NULL DEFAULT 1,
  `subscriptionStartTime`   BIGINT      NOT NULL,
  `subscriptionEndTime`     BIGINT      NOT NULL,
  `created`                 TIMESTAMP   NOT NULL DEFAULT current_timestamp,
  `lastAccess`              TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `dealerId` (`dealerId`),
  CONSTRAINT `dealerId_subscription_fk` FOREIGN KEY (`dealerId`) REFERENCES `Dealer` (`id`)
)ENGINE = InnoDB, DEFAULT CHARSET = latin1;

DROP TABLE IF EXISTS NetworkAccessRequest;
CREATE TABLE IF NOT EXISTS NetworkAccessRequest (
  `id`                        BIGINT        NOT NULL AUTO_INCREMENT,
  `uuid`                      BINARY(36)    NOT NULL,
  `networkId`                 VARCHAR(255)  NOT NULL,
  `dealerId`                  BIGINT        NOT NULL,
  `valid`                     TINYINT(1)    NOT NULL DEFAULT 1,
  `expires`                   BIGINT        NOT NULL DEFAULT 40000000000,
  `requestedDurationOfAccess` BIGINT        NULL,
  `created`                   TIMESTAMP     NOT NULL DEFAULT current_timestamp,
  `lastAccess`                TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `dealerId` (`dealerId`),
  CONSTRAINT `dealerId_network_access_request_fk` FOREIGN KEY (`dealerId`) REFERENCES `Dealer` (`id`)
)ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE Dealer ADD `fleetManager` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE Dealer ADD `externalRefId` VARCHAR(255) NULL;
ALTER TABLE Dealer ADD `extendedService` VARCHAR(255) NULL;



DROP DATABASE IF EXISTS CV_Issue;
CREATE SCHEMA IF NOT EXISTS CV_Issue
  DEFAULT CHARACTER SET utf8
  COLLATE utf8_general_ci;
USE CV_Issue;

DROP TABLE IF EXISTS Authorization;

CREATE TABLE IF NOT EXISTS Authorization (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `serviceName` VARCHAR(255) NOT NULL,
  `key`         VARCHAR(255) NOT NULL,
  `secret`      VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET=latin1;

INSERT INTO Authorization (`serviceName`, `key`, `secret`) VALUES ('testService', 'key', SHA2('secret', 256));


DROP TABLE IF EXISTS IssueType;
CREATE TABLE IF NOT EXISTS IssueType (
    `id`          BIGINT       NOT NULL AUTO_INCREMENT,
    `uuid`        BINARY(36)   NOT NULL,
    `name`        VARCHAR(255) NOT NULL,
    `description` VARCHAR(255) NULL,
    `valid`       TINYINT      NOT NULL     DEFAULT 1,
    `created`     TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
    `updated`     TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `creator`     VARCHAR(36)  NOT NULL     DEFAULT "SYSTEM",
    PRIMARY KEY (`id`),
    INDEX `uuid` (`uuid`)

)ENGINE = InnoDB, DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS WorkflowStageStatus;
CREATE TABLE IF NOT EXISTS WorkflowStageStatus (
    `id`                 BIGINT       NOT NULL AUTO_INCREMENT,
    `uuid`               BINARY(36)   NOT NULL,
    `status`             VARCHAR(255) NOT NULL UNIQUE,
    `description`        TEXT         NOT NULL,
    `valid`              TINYINT(1)   NOT NULL DEFAULT 1,
    `lastAccess`         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `created`            TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `uuid` (`uuid`)
)ENGINE = InnoDB, DEFAULT CHARSET=latin1;

INSERT INTO WorkflowStageStatus SET uuid=UUID(), status="initiated", description="starting";
INSERT INTO WorkflowStageStatus SET uuid=UUID(), status="waiting_for_service_response", description="waiting";
INSERT INTO WorkflowStageStatus SET uuid=UUID(), status="in_progress", description="working";
INSERT INTO WorkflowStageStatus SET uuid=UUID(), status="more_info_needed", description="idk";
INSERT INTO WorkflowStageStatus SET uuid=UUID(), status="completed", description="done";


DROP TABLE IF EXISTS WorkflowStage;
CREATE TABLE IF NOT EXISTS WorkflowStage (
    `id`                     BIGINT       NOT NULL AUTO_INCREMENT,
    `uuid`                   BINARY(36)   NOT NULL,
    `issueId`                BIGINT       NULL,
    `description`            TEXT         NOT NULL,
    `title`		             TEXT         NOT NULL,
    `workflowStageStatusId`  BIGINT       NOT NULL,
    `valid`					 TINYINT(1)   NOT NULL DEFAULT 1,
	`created`            TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `lastAccess`         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    Index `workflowStageStatusId` (`workflowStageStatusId`),
    CONSTRAINT `workflowStageStatusId_workflowStage_fk` FOREIGN KEY (`workflowStageStatusId`) REFERENCES `WorkflowStageStatus` (`id`)
)ENGINE = InnoDB, DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS Issue;
CREATE TABLE IF NOT EXISTS Issue (
    `id`                   BIGINT       NOT NULL AUTO_INCREMENT,
    `uuid`                 BINARY(36)   NOT NULL,
    `userUuid`             BINARY(36)   NOT NULL,
    `boatUuid`             BINARY(36)   NOT NULL,
    `title`                VARCHAR(255) NOT NULL,
    `description`          TEXT         NOT NULL,
    `issueTypeId`          BIGINT       NULL,
    `workflowStageId`      BIGINT       NULL,
    `componentUuid`        BINARY(36)   NULL,
    `initiatedDate`        BIGINT       NOT NULL,
    `completeByDate`       BIGINT       NULL,
    `completedDate`        BIGINT       NULL,
    `assigned`             TINYINT(1)   NOT NULL DEFAULT 0,
    `resolved`             TINYINT(1)   NOT NULL DEFAULT 0,
    `resolvedDate`         BIGINT       NULL,
    `creator`              BINARY(36)   NOT NULL DEFAULT 'SYSTEM',
    `valid`                TINYINT(1)   NOT NULL DEFAULT 1,
    `lastAccess`           TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `created`              TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `uuid` (`uuid`),
    CONSTRAINT `workflowStageId_issue_fk` FOREIGN KEY (`workflowStageId`) REFERENCES `WorkflowStage` (`id`),
    CONSTRAINT `issueTypeId_issue_fk` FOREIGN KEY (`issueTypeId`) REFERENCES `IssueType` (`id`)
)ENGINE = InnoDB, DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS IssueAlert;
CREATE TABLE IF NOT EXISTS IssueAlert (
    `id`                     BIGINT       NOT NULL AUTO_INCREMENT,
    `uuid`                   BINARY(36)   NOT NULL,
    `issueId`                BIGINT       NULL,
    `alertId`                VARCHAR(24)  NOT NULL,
    `alertUuid`                BINARY(36)  NOT NULL,
    `valid`					 TINYINT(1)   NOT NULL DEFAULT 1,
	`created`            TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `lastAccess`         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    CONSTRAINT `issuealert_issue_fk` FOREIGN KEY (`issueId`) REFERENCES `Issue` (`id`)
)ENGINE = InnoDB, DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS Photo;
CREATE TABLE IF NOT EXISTS Photo (
    `id`                          BIGINT       NOT NULL AUTO_INCREMENT,
    `uuid`                        BINARY(36)   NOT NULL,
    `url` 			              VARCHAR(512) CHARACTER SET "ascii" COLLATE "ascii_general_ci" NULL,
    `image`                       TEXT         NULL,
    `caption`                     TEXT         NULL,
    `issueId`                     BIGINT       NOT NULL,
    `valid`                       TINYINT(1)   NOT NULL DEFAULT 1,
    `created`                     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `lastAccess`                  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `uuid` (`id`),
   CONSTRAINT `issueId_photos_fk` FOREIGN KEY (`issueId`) REFERENCES `Issue` (`id`)
)ENGINE = InnoDB, DEFAULT CHARSET=latin1;



DROP DATABASE IF EXISTS CV_Maintenance;
CREATE SCHEMA IF NOT EXISTS CV_Maintenance
  DEFAULT CHARACTER SET utf8
  COLLATE utf8_general_ci;
USE CV_Maintenance;

ALTER DATABASE CV_Maintenance
CHARACTER SET utf8mb4
COLLATE utf8mb4_general_ci;

DROP TABLE IF EXISTS Authorization;

CREATE TABLE IF NOT EXISTS Authorization (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `serviceName` VARCHAR(255) NOT NULL,
  `key`         VARCHAR(255) NOT NULL,
  `secret`      VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE Authorization
  CONVERT TO CHARACTER SET utf8
  COLLATE utf8_general_ci;

INSERT INTO Authorization (`serviceName`, `key`, `secret`) VALUES ('testService', 'key', SHA2('secret', 256));

DROP TABLE IF EXISTS MaintenanceRep;
CREATE TABLE IF NOT EXISTS MaintenanceRep (
  `id`             BIGINT       NOT NULL     AUTO_INCREMENT,
  `uuid`           BINARY(36)   NOT NULL,
  `userUuid`       BINARY(36)   NOT NULL,
  `preferredEmail` VARCHAR(255) NOT NULL UNIQUE,
  `preferredPhone` VARCHAR(20)  NULL,
  `isConcierge`    TINYINT(1) 	NOT NULL     DEFAULT 0,
  `valid`          TINYINT(1)   NOT NULL     DEFAULT 1,
  `lastAccess`     TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`        TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `uuid` (`uuid`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE MaintenanceRep
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX uuid,
  ADD UNIQUE INDEX uuid_idx (uuid),
  ADD UNIQUE INDEX user_idx (userUuid);

DROP TABLE IF EXISTS BoatOwners;
CREATE TABLE IF NOT EXISTS BoatOwners (
  `id`               BIGINT     NOT NULL AUTO_INCREMENT,
  `maintenanceRepId` BIGINT     NOT NULL,
  `boatOwnerUuid`    BINARY(36) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `maintenanceRepId` (`maintenanceRepId`),
  CONSTRAINT `maintenanceRepId_BoatOwners_fk` FOREIGN KEY (`maintenanceRepId`) REFERENCES `MaintenanceRep` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE BoatOwners
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

DROP TABLE IF EXISTS Dealerships;
CREATE TABLE IF NOT EXISTS Dealerships (
  `id`               BIGINT     NOT NULL AUTO_INCREMENT,
  `maintenanceRepId` BIGINT     NOT NULL,
  `dealerUuid`       BINARY(36) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `maintenanceRepId` (`maintenanceRepId`),
  CONSTRAINT `maintenanceRepId_Dealerships_fk` FOREIGN KEY (`maintenanceRepId`) REFERENCES `MaintenanceRep` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE Dealerships
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  ADD INDEX dealer_idx (dealerUuid);

DROP TABLE IF EXISTS Issues;
CREATE TABLE IF NOT EXISTS Issues (
  `id`               BIGINT     NOT NULL AUTO_INCREMENT,
  `maintenanceRepId` BIGINT     NOT NULL,
  `issueUuid`        BINARY(36) NOT NULL,
  `boatOwnerUuid`    BINARY(36) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `maintenanceRepId` (`maintenanceRepId`),
  CONSTRAINT `maintenanceRepId_Issues_fk` FOREIGN KEY (`maintenanceRepId`) REFERENCES `MaintenanceRep` (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE Issues
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP FOREIGN KEY maintenanceRepId_Issues_fk,
  DROP INDEX maintenanceRepId,
  ADD FOREIGN KEY maintenanceRepId_Issues_fk (`maintenanceRepId`) REFERENCES `MaintenanceRep` (`id`);

DROP TABLE IF EXISTS MaintenanceRepSubscription;
CREATE TABLE IF NOT EXISTS MaintenanceRepSubscription (
  `id`                      BIGINT        NOT NULL AUTO_INCREMENT,
  `uuid`                    BINARY(36)    NOT NULL,
  `maintenanceRepId`        BIGINT        NOT NULL,
  `valid`                   TINYINT(1)    NOT NULL DEFAULT 1, 
  `subscriptionStartTime`   BIGINT        NOT NULL,
  `subscriptionEndTime`     BIGINT        NOT NULL,
  `networkId`               VARCHAR(255)  NOT NULL,
  `created`                 TIMESTAMP     NOT NULL DEFAULT current_timestamp,
  `lastAccess`              TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `maintenanceRepId` (`maintenanceRepId`),
  CONSTRAINT `maintenanceRep_subscription_fk` FOREIGN KEY (`maintenanceRepId`) REFERENCES `MaintenanceRep` (`id`)
)ENGINE = InnoDB, DEFAULT CHARSET = latin1;

ALTER TABLE MaintenanceRep ADD `externalRefId` VARCHAR(255) NULL;
ALTER TABLE MaintenanceRep ADD `extendedService` VARCHAR(255) NULL;

DROP DATABASE IF EXISTS CV_Media;
CREATE SCHEMA IF NOT EXISTS CV_Media
  DEFAULT CHARACTER SET utf8
  COLLATE utf8_general_ci;
USE CV_Media;

ALTER DATABASE CHARACTER SET utf8mb4
COLLATE utf8mb4_general_ci;

DROP TABLE IF EXISTS Authorization;

CREATE TABLE IF NOT EXISTS Authorization (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `serviceName` VARCHAR(255) NOT NULL,
  `key`         VARCHAR(255) NOT NULL,
  `secret`      VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = utf8;

ALTER TABLE Authorization
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

DROP TABLE IF EXISTS `Media`;
CREATE TABLE IF NOT EXISTS `Media` (
  `id`                              BIGINT       NOT NULL     AUTO_INCREMENT,
  `uuid`                            BINARY(36)   NOT NULL,
  `contentType`                     VARCHAR(255) NOT NULL, 
  `title`                           VARCHAR(255) NULL,
  `shortDescription`                TEXT         NULL,
  `longDescription`                 TEXT         NULL,
  `thumbnailEncoded`                TEXT         NULL,
  `uploaded`                        TINYINT      NOT NULL    DEFAULT 0,
  `filename`                        VARCHAR(512) NOT NULL,
  `valid`                           TINYINT      NOT NULL     DEFAULT 1,
  `created`                         TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `updated`                         TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creator`                         BINARY(36)   NOT NULL     DEFAULT "SYSTEM",
  PRIMARY KEY (`id`)
);

-- This should be moved to separate file
INSERT INTO Authorization (`serviceName`, `key`, `secret`) VALUES ('testService', 'key', SHA2('secret', 256));



#
# Copyright (c) 2015 - 2017. Technicity LLC. All rights reserved.
#
DROP DATABASE IF EXISTS `CV_User`;
CREATE SCHEMA IF NOT EXISTS `CV_User`
  DEFAULT CHARACTER SET utf8
  COLLATE utf8_general_ci;
USE `CV_User`;

ALTER DATABASE
CHARACTER SET utf8mb4
COLLATE utf8mb4_general_ci;

-- -----------------------------------------------------
-- Table `Authorization`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Authorization`;

CREATE TABLE IF NOT EXISTS `Authorization` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `serviceName` VARCHAR(255) NOT NULL,
  `key`         VARCHAR(255) NOT NULL,
  `secret`      VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB;

ALTER TABLE Authorization
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

INSERT INTO Authorization (`serviceName`, `key`, `secret`) VALUES ('testService', 'key', SHA2('secret', 256));


DROP TABLE IF EXISTS `User`;
CREATE TABLE IF NOT EXISTS `User` (
  `id`                              BIGINT       NOT NULL     AUTO_INCREMENT,
  `uuid`                            BINARY(36)   NOT NULL,
  `firstName`                       VARCHAR(255) NOT NULL,
  `lastName`                        VARCHAR(255) NOT NULL,
  `email`                           VARCHAR(255) NOT NULL     UNIQUE,
  `password`                        VARCHAR(255) NOT NULL,
  `phone`                           VARCHAR(255) NULL,
  `avatarImageLocation`             VARCHAR(255) NULL,
  `isBoatOwnerUser`                 TINYINT      NOT NULL     DEFAULT 0,
  `isMaintenanceRepUser`            TINYINT      NOT NULL     DEFAULT 0,
  `isSuperUser`                     TINYINT      NOT NULL     DEFAULT 0,
  `isOEMUser`                       TINYINT      NOT NULL     DEFAULT 0,
  `isFleetOwner`                    TINYINT      NOT NULL     DEFAULT 0,
  `hasAcceptedTermsAndConditions`   TINYINT(1)   NOT NULL     DEFAULT 0,
  `hasSubscribedToMarketing`        TINYINT(1)   NOT NULL     DEFAULT 0,
  `created`                         TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `updated`                         TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creator`                         BINARY(36)   NOT NULL     DEFAULT "SYSTEM",
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB;

ALTER TABLE User
  ADD COLUMN `preferredTimezone` VARCHAR(255) NULL DEFAULT 'America/Chicago';

ALTER TABLE User
  ADD INDEX boat_owner_idx (isBoatOwnerUser),
  ADD INDEX maint_rep_idx  (isMaintenanceRepUser),
  ADD INDEX super_use_idx (isSuperUser),
  ADD INDEX oem_idx (isOEMUser),
  ADD INDEX fleet_idx (isFleetOwner),
  ADD UNIQUE INDEX uuid_idx (uuid);

ALTER TABLE User
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  MODIFY COLUMN creator CHAR(36) NOT NULL DEFAULT "SYSTEM";


DROP TABLE IF EXISTS `Address`;
CREATE TABLE IF NOT EXISTS `Address` (
  `id`        BIGINT       NOT NULL     AUTO_INCREMENT,
  `uuid`      BINARY(36)   NOT NULL,
  `address1`  VARCHAR(255) NOT NULL,
  `address2`  VARCHAR(255) NULL,
  `city`      VARCHAR(255) NULL,
  `state`     VARCHAR(2)   NULL,
  `zip5`      VARCHAR(5)   NULL,
  `zip4`      VARCHAR(4)   NULL,
  `isBilling` TINYINT(1)   NOT NULL     DEFAULT 0,
  `valid`     TINYINT      NOT NULL     DEFAULT 1,
  `isPrimary` TINYINT      NOT NULL     DEFAULT 0,
  `created`   TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `updated`   TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creator`   BINARY(36)   NOT NULL     DEFAULT "SYSTEM",
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB;

ALTER TABLE Address
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  ADD UNIQUE INDEX uuid_idx (`uuid`);

ALTER TABLE Address
  DROP INDEX uuid_idx,
  ADD UNIQUE INDEX uuid_idx (`uuid`, valid),
  MODIFY COLUMN creator CHAR(36) NOT NULL DEFAULT "SYSTEM";


DROP TABLE IF EXISTS `UserAddress`;
CREATE TABLE IF NOT EXISTS `UserAddress` (
  `id`        BIGINT    NOT NULL     AUTO_INCREMENT,
  `addressId` BIGINT    NOT NULL,
  `userId`    BIGINT    NOT NULL,
  `valid`     TINYINT   NOT NULL     DEFAULT 1,
  `created`   TIMESTAMP NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `updated`   TIMESTAMP NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creator`   CHAR(36)  NOT NULL     DEFAULT "SYSTEM",
  PRIMARY KEY (`id`),
  FOREIGN KEY `address_address_fk` (`addressId`) REFERENCES `Address` (`id`),
  FOREIGN KEY `address_user_fk` (`userId`) REFERENCES `User` (`id`)
)
  ENGINE = InnoDB;

ALTER TABLE UserAddress
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

ALTER TABLE UserAddress
  ADD INDEX addr_idx (addressId, userId, valid),
  MODIFY COLUMN creator CHAR(36) NOT NULL DEFAULT "SYSTEM";

DROP TABLE IF EXISTS `UserNetwork`;
CREATE TABLE IF NOT EXISTS `UserNetwork` (
  `id`              BIGINT       NOT NULL     AUTO_INCREMENT,
  `userId`          BIGINT       NOT NULL,
  `networkId`       VARCHAR(255) NOT NULL,
  `expires`         BIGINT       NOT NULL     DEFAULT 40000000000,
  `trialDuration`   BIGINT       NOT NULL     DEFAULT 864000,
  `isPrimary`       TINYINT(1)   NOT NULL     DEFAULT 0,
  `valid`           TINYINT      NOT NULL     DEFAULT 1,
  `created`         TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `updated`         TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creator`         BINARY(36)   NOT NULL     DEFAULT "SYSTEM",
  PRIMARY KEY (`id`),
  FOREIGN KEY `networkId_user_fk` (`userId`) REFERENCES `User` (`id`)
)
  ENGINE = InnoDB;

ALTER TABLE UserNetwork
  ADD INDEX network_expires_idx (expires),
  MODIFY COLUMN creator CHAR(36) NOT NULL DEFAULT "SYSTEM";

ALTER TABLE UserNetwork
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX network_expires_idx,
  ADD INDEX user_valid_idx (userId, valid),
  ADD INDEX network_expiredate_valid_idx (networkId, expires, valid);

DROP TABLE IF EXISTS `UserHub`;
CREATE TABLE IF NOT EXISTS `UserHub` (
  `id`      BIGINT       NOT NULL     AUTO_INCREMENT,
  `userId`  BIGINT       NOT NULL,
  `hubId`   VARCHAR(255) NOT NULL,
  `expires` BIGINT       NOT NULL     DEFAULT 40000000000,
  `valid`   TINYINT      NOT NULL     DEFAULT 1,
  `created` TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `updated` TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creator` BINARY(36)   NOT NULL     DEFAULT "SYSTEM",
  PRIMARY KEY (`id`),
  FOREIGN KEY `hubId_user_fk` (`userId`) REFERENCES `User` (`id`)
)
  ENGINE = InnoDB;

ALTER TABLE UserHub
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

ALTER TABLE UserHub
  ADD INDEX hub_idx (hubId, valid),
  MODIFY COLUMN creator CHAR(36) NOT NULL DEFAULT "SYSTEM";

DROP TABLE IF EXISTS `UserPuck`;
CREATE TABLE IF NOT EXISTS `UserPuck` (
  `id`      BIGINT       NOT NULL     AUTO_INCREMENT,
  `userId`  BIGINT       NOT NULL,
  `puckId`  VARCHAR(255) NOT NULL,
  `expires` BIGINT       NOT NULL     DEFAULT 40000000000,
  `valid`   TINYINT      NOT NULL     DEFAULT 1,
  `created` TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `updated` TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creator` BINARY(36)   NOT NULL     DEFAULT "SYSTEM",
  PRIMARY KEY (`id`),
  FOREIGN KEY `puckId_user_fk` (`userId`) REFERENCES `User` (`id`)
)
  ENGINE = InnoDB;

ALTER TABLE UserPuck
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

ALTER TABLE UserPuck
  ADD INDEX puck_idx (puckId, valid),
  MODIFY COLUMN creator CHAR(36) NOT NULL DEFAULT "SYSTEM",
  ADD INDEX userId_valid_idx (userId, valid);

DROP TABLE IF EXISTS `UserBoat`;
CREATE TABLE IF NOT EXISTS `UserBoat` (
  `id`       BIGINT     NOT NULL     AUTO_INCREMENT,
  `userId`   BIGINT     NOT NULL,
  `boatUuid` BINARY(36) NOT NULL,
  `expires`  BIGINT     NOT NULL     DEFAULT 40000000000,
  `valid`    TINYINT    NOT NULL     DEFAULT 1,
  `created`  TIMESTAMP  NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `updated`  TIMESTAMP  NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creator`  BINARY(36) NOT NULL     DEFAULT "SYSTEM",
  PRIMARY KEY (`id`),
  FOREIGN KEY `boatUuid_user_fk` (`userId`) REFERENCES `User` (`id`)
)
  ENGINE = InnoDB;

ALTER TABLE UserBoat
  ADD INDEX boat_uuid_idx (boatUuid, valid);

ALTER TABLE UserBoat
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

ALTER TABLE UserBoat
  DROP INDEX boat_uuid_idx,
  ADD INDEX boat_uuid_idx (boatUuid, valid),
  MODIFY COLUMN creator CHAR(36) NOT NULL DEFAULT "SYSTEM",
  ADD INDEX created_user_idx (created DESC, userId, valid);


DROP TABLE IF EXISTS `NewUserAccessCode`;
CREATE TABLE IF NOT EXISTS `NewUserAccessCode` (
  `id`                BIGINT       NOT NULL     AUTO_INCREMENT,
  `userId`            BIGINT       NOT NULL,
  `newUserAccessCode` VARCHAR(255) NOT NULL,
  `networkId`         VARCHAR(255) NOT NULL,
  `expires`           BIGINT       NOT NULL     DEFAULT 0,
  `valid`             TINYINT      NOT NULL     DEFAULT 1,
  `created`           TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `updated`           TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creator`           VARCHAR(36)  NOT NULL     DEFAULT "SYSTEM",
  PRIMARY KEY (`id`),
  FOREIGN KEY `accessCodeId_user_fk` (`userId`) REFERENCES `User` (`id`)
)
  ENGINE = InnoDB;

ALTER TABLE NewUserAccessCode
  ADD INDEX access_code_idx (newUserAccessCode, expires);

ALTER TABLE NewUserAccessCode
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

SHOW CREATE TABLE NewUserAccessCode;
ALTER TABLE NewUserAccessCode
  DISABLE KEYS,
  ADD INDEX user_idx (userId, valid),
  ADD INDEX user_expires (userId, expires, valid),
  ADD INDEX code_expires_valid_idx (newUserAccessCode, expires, valid),
  ADD FOREIGN KEY newuseraccesscode_ibfk_1 (userId) REFERENCES User (`id`),
  MODIFY COLUMN creator CHAR(36) NOT NULL DEFAULT "SYSTEM",
  ENABLE KEYS;


DROP TABLE IF EXISTS `ResetPasswordToken`;
CREATE TABLE IF NOT EXISTS `ResetPasswordToken` (
  `id`      BIGINT       NOT NULL     AUTO_INCREMENT,
  `userId`  BIGINT       NOT NULL,
  `email`   VARCHAR(255) NOT NULL,
  `token`   TEXT         NOT NULL,
  `expires` BIGINT       NOT NULL,
  `valid`   TINYINT      NOT NULL     DEFAULT 1,
  `created` TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `updated` TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creator` VARCHAR(36)  NOT NULL     DEFAULT "SYSTEM",
  PRIMARY KEY (`id`),
  FOREIGN KEY `token_user_fk` (`userId`) REFERENCES `User` (`id`)
)
  ENGINE = InnoDB;

ALTER TABLE ResetPasswordToken
  ADD INDEX email_token_expires (email, token(100), expires);

ALTER TABLE ResetPasswordToken
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX email_token_expires,
  ADD INDEX email_token_expires (email, token(100), expires, valid),
  MODIFY COLUMN creator CHAR(36) NOT NULL DEFAULT "SYSTEM";

DROP TABLE IF EXISTS `PrivilegeType`;
CREATE TABLE IF NOT EXISTS `PrivilegeType` (
  `id`                BIGINT       NOT NULL     AUTO_INCREMENT,
  `enum`              VARCHAR(255) NOT NULL UNIQUE,
  `description`       TEXT         NOT NULL,
  `shortDescription`  VARCHAR(255) NULL,
  `clientDescription` TEXT         NULL,
  `userType`          VARCHAR(255) NOT NULL     DEFAULT "BOAT_OWNER",
  `valid`             TINYINT      NOT NULL     DEFAULT 1,
  `created`           TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `updated`           TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creator`           VARCHAR(36)  NOT NULL     DEFAULT "SYSTEM",
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB;

CREATE INDEX privtype_enum_index
  ON PrivilegeType (enum);

ALTER TABLE PrivilegeType
  MODIFY COLUMN description TEXT CHARACTER SET utf8mb4
COLLATE utf8mb4_general_ci NOT NULL,
  MODIFY COLUMN shortDescription VARCHAR(255) CHARACTER SET utf8mb4
COLLATE utf8mb4_general_ci NULL,
  MODIFY COLUMN clientDescription VARCHAR(255) CHARACTER SET utf8mb4
COLLATE utf8mb4_general_ci;

ALTER TABLE PrivilegeType
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  MODIFY COLUMN creator CHAR(36) NOT NULL DEFAULT "SYSTEM";

DROP TABLE IF EXISTS `UserPrivilege`;
CREATE TABLE IF NOT EXISTS `UserPrivilege` (
  `id`              BIGINT      NOT NULL     AUTO_INCREMENT,
  `uuid`            VARCHAR(36) NULL,
  `userId`          BIGINT      NOT NULL,
  `privilegeTypeId` BIGINT      NOT NULL,
  `read`            TINYINT     NOT NULL     DEFAULT 0,
  `write`           TINYINT     NOT NULL     DEFAULT 0,
  `update`          TINYINT     NOT NULL     DEFAULT 0,
  `remove`          TINYINT     NOT NULL     DEFAULT 0,
  `valid`           TINYINT     NOT NULL     DEFAULT 1,
  `created`         TIMESTAMP   NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `updated`         TIMESTAMP   NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creator`         VARCHAR(36) NOT NULL     DEFAULT "SYSTEM",
  PRIMARY KEY (`id`),
  FOREIGN KEY `priv_privtype_fk` (`privilegeTypeId`) REFERENCES `PrivilegeType` (`id`),
  FOREIGN KEY `priv_user_fk` (`userId`) REFERENCES `User` (`id`)
)
  ENGINE = InnoDB;

CREATE INDEX priv_userId_index
  ON UserPrivilege (userId);

ALTER TABLE UserPrivilege
  ADD UNIQUE INDEX uuid_idx (uuid);

ALTER TABLE UserPrivilege
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

ALTER TABLE UserPrivilege
  DROP INDEX uuid_idx,
  ADD UNIQUE INDEX uuid_idx (`uuid`, valid),
  MODIFY COLUMN creator CHAR(36) NOT NULL DEFAULT "SYSTEM",
  DROP INDEX priv_userId_index,
  ADD INDEX priv_userId_index (userId, valid);

DROP TABLE IF EXISTS `PrivilegeTemplate`;
CREATE TABLE IF NOT EXISTS `PrivilegeTemplate` (
  `id`          BIGINT       NOT NULL     AUTO_INCREMENT,
  `uuid`        VARCHAR(36)  NOT NULL,
  `name`        VARCHAR(255) NOT NULL,
  `description` VARCHAR(255) NULL,
  `userType`    VARCHAR(255) NOT NULL     DEFAULT "GENERAL",
  `valid`       TINYINT      NOT NULL     DEFAULT 1,
  `created`     TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `updated`     TIMESTAMP    NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creator`     VARCHAR(36)  NOT NULL     DEFAULT "SYSTEM",
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB;

ALTER TABLE PrivilegeTemplate
  ADD UNIQUE INDEX uuid_idx (uuid);

ALTER TABLE PrivilegeTemplate
  MODIFY COLUMN description VARCHAR(255) CHARACTER SET utf8mb4
COLLATE utf8mb4_general_ci NULL;

ALTER TABLE PrivilegeTemplate
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX uuid_idx,
  ADD UNIQUE INDEX uuid_idx (`uuid`, valid),
  MODIFY COLUMN creator CHAR(36) NOT NULL DEFAULT "SYSTEM";

DROP TABLE IF EXISTS `TemplatePrivilege`;
CREATE TABLE IF NOT EXISTS `TemplatePrivilege` (
  `id`              BIGINT      NOT NULL     AUTO_INCREMENT,
  `uuid`            VARCHAR(36) NOT NULL,
  `templateId`      BIGINT      NOT NULL,
  `privilegeTypeId` BIGINT      NOT NULL,
  `read`            TINYINT     NOT NULL     DEFAULT 0,
  `write`           TINYINT     NOT NULL     DEFAULT 0,
  `update`          TINYINT     NOT NULL     DEFAULT 0,
  `remove`          TINYINT     NOT NULL     DEFAULT 0,
  `valid`           TINYINT     NOT NULL     DEFAULT 1,
  `created`         TIMESTAMP   NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `updated`         TIMESTAMP   NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creator`         VARCHAR(36) NOT NULL     DEFAULT "SYSTEM",
  PRIMARY KEY (`id`),
  FOREIGN KEY `templatepriv_privtemplate_fk` (`templateId`) REFERENCES `PrivilegeTemplate` (`id`),
  FOREIGN KEY `templatepriv_priv_fk` (`privilegeTypeId`) REFERENCES `PrivilegeType` (`id`)
)
  ENGINE = InnoDB;

ALTER TABLE TemplatePrivilege
  ADD UNIQUE INDEX uuid_idx (uuid);

ALTER TABLE TemplatePrivilege
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX uuid_idx,
  ADD UNIQUE INDEX uuid_idx (`uuid`, valid),
  MODIFY COLUMN creator CHAR(36) NOT NULL DEFAULT "SYSTEM";

DROP TABLE IF EXISTS `UserTemplatePrivilegeLedger`;
CREATE TABLE IF NOT EXISTS `UserTemplatePrivilegeLedger` (
  `id`         BIGINT      NOT NULL     AUTO_INCREMENT,
  `uuid`       VARCHAR(36) NULL,
  `userId`     BIGINT      NOT NULL,
  `templateId` BIGINT      NOT NULL,
  `isModified` TINYINT     NOT NULL     DEFAULT 0
  COMMENT "Marked if privilege set is modified from base template",
  `changed`    TINYINT     NOT NULL     DEFAULT 0
  COMMENT "Marked if privilege template was changed.  Should be invalidated",
  `valid`      TINYINT     NOT NULL     DEFAULT 1,
  `created`    TIMESTAMP   NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `updated`    TIMESTAMP   NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creator`    VARCHAR(36) NOT NULL     DEFAULT "SYSTEM",
  PRIMARY KEY (`id`),
  FOREIGN KEY `privusertemplateledger_user_fk` (`userId`) REFERENCES `User` (`id`),
  FOREIGN KEY `privusertemplateledger_template_fk` (`templateId`) REFERENCES `PrivilegeTemplate` (`id`)
)
  ENGINE = InnoDB;

ALTER TABLE UserTemplatePrivilegeLedger
  ADD UNIQUE INDEX uuid_idx (uuid);

ALTER TABLE UserTemplatePrivilegeLedger
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  DROP INDEX uuid_idx,
  ADD UNIQUE INDEX uuid_idx (`uuid`, valid),
  MODIFY COLUMN creator CHAR(36) NOT NULL DEFAULT "SYSTEM",
  ADD INDEX user_valid_idx (userId, valid);

DROP TABLE IF EXISTS `UserFeedback`;
CREATE TABLE IF NOT EXISTS `UserFeedback` (
  `id`      BIGINT      NOT NULL     AUTO_INCREMENT,
  `uuid`    VARCHAR(36) NOT NULL,
  `userId`  BIGINT      NOT NULL,
  `time`    BIGINT      NOT NULL,
  `payload` TEXT        NOT NULL,
  `created` TIMESTAMP   NOT NULL     DEFAULT CURRENT_TIMESTAMP,
  `updated` TIMESTAMP   NOT NULL     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creator` VARCHAR(36) NOT NULL     DEFAULT "SYSTEM",
  PRIMARY KEY (`id`),
  FOREIGN KEY `feedback_user_fk` (`userId`) REFERENCES `User` (`id`)
)
  ENGINE = InnoDB;

ALTER TABLE UserFeedback
  ADD UNIQUE INDEX uuid_idx(uuid);

ALTER TABLE UserFeedback
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci,
  MODIFY COLUMN creator CHAR(36) NOT NULL DEFAULT "SYSTEM";

ALTER TABLE User ADD `externalRefId` VARCHAR(255) NULL;
ALTER TABLE User ADD `extendedService` VARCHAR(255) NULL;


DROP DATABASE IF EXISTS CV_VesselViewMobile;
CREATE SCHEMA IF NOT EXISTS CV_VesselViewMobile
  DEFAULT CHARACTER SET utf8
  COLLATE utf8_general_ci;
USE CV_VesselViewMobile;

ALTER DATABASE CHARACTER SET utf8mb4
COLLATE utf8mb4_general_ci;

DROP TABLE IF EXISTS Authorization;

CREATE TABLE IF NOT EXISTS Authorization (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `serviceName` VARCHAR(255) NOT NULL,
  `key`         VARCHAR(255) NOT NULL,
  `secret`      VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET = utf8;

ALTER TABLE Authorization
  CONVERT TO CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

-- This should be moved to separate file
INSERT INTO Authorization (`serviceName`, `key`, `secret`) VALUES ('testService', 'key', SHA2('secret', 256));



DROP DATABASE IF EXISTS CV_Payment;
CREATE SCHEMA IF NOT EXISTS CV_Payment
  DEFAULT CHARACTER SET utf8
  COLLATE utf8_general_ci;
USE CV_Payment;

DROP TABLE IF EXISTS Authorization;

CREATE TABLE IF NOT EXISTS Authorization (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `serviceName` VARCHAR(255) NOT NULL,
  `key`         VARCHAR(255) NOT NULL,
  `secret`      VARCHAR(255) NOT NULL,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB, DEFAULT CHARSET=latin1;

INSERT INTO Authorization (`serviceName`, `key`, `secret`) VALUES ('testService', 'key', SHA2('secret', 256));


DROP TABLE IF EXISTS Product;
CREATE TABLE IF NOT EXISTS Product (
  `id`                BIGINT       NOT NULL AUTO_INCREMENT,
  `uuid`              VARCHAR(36) NOT NULL,
  `name`              VARCHAR(255) NOT NULL,
  `description`       VARCHAR(255) NULL,
  `sku`               VARCHAR(50)  NULL,
  `imageBaseUrl`      TEXT NULL,
  `bestValue`         TINYINT(1) NULL,
  `productIdentifier` VARCHAR(50)  NULL,
  `unitPrice`         DECIMAL(13,2) NOT NULL,
  `productLifespan`   BIGINT NULL,
  `additionalData`    JSON NULL,
  `inStock`           TINYINT(1) NOT NULL DEFAULT 1,
  `valid`             TINYINT(1) NOT NULL DEFAULT 1,
  `lastAccess`        TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`           TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) 
)ENGINE = InnoDB, DEFAULT CHARSET=utf8;

INSERT INTO Product SET `name`="1 year subscription", `uuid` = "b9425ad0-de04-4c48-89cb-3ad73633435a", `description`="A 1 year subscription to Nautic-ON to support transmission of data from your boat to Nautic-ON.", `bestValue`=1, `unitPrice`=149.00, `productLifespan` = 31536000;



INSERT INTO Product SET `name`="6 month Seasonal subscription", `uuid` = "c9425ad0-de04-4c48-89cb-3ad73633435a", `description`="A 6 month seasonal subscription to Nautic-ON to support transmission of data from your boat to Nautic-ON.", `bestValue`=0, `unitPrice`=114.00, `productLifespan` = 15768000;

DROP TABLE IF EXISTS UserCardToken;
CREATE TABLE IF NOT EXISTS UserCardToken (
  `id`                BIGINT       NOT NULL AUTO_INCREMENT,
  `userUuid`          VARCHAR(36) NOT NULL,
  `token`             VARCHAR(255) NOT NULL,
  `cardData`          JSON NULL,
  `valid`             TINYINT(1) NOT NULL DEFAULT 1,
  `lastAccess`        TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`           TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) 
)ENGINE = InnoDB, DEFAULT CHARSET=utf8;

CREATE INDEX userUuid_userCardToken_idx ON UserCardToken (userUuid);


DROP TABLE IF EXISTS ProductOrder;
CREATE TABLE IF NOT EXISTS ProductOrder (
  `id`                BIGINT       NOT NULL AUTO_INCREMENT,
  `userUuid`          VARCHAR(36) NOT NULL,
  `uuid`              VARCHAR(36) NOT NULL,
  `networkId`         VARCHAR(24) NULL,
  `reusableToken`     TINYINT(1) NOT NULL,
  `successful`        TINYINT(1) NOT NULL DEFAULT 0,
  `additionalData`    JSON NULL,
  `valid`             TINYINT(1) NOT NULL DEFAULT 1,
  `lastAccess`        TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created`           TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) 
)ENGINE = InnoDB, DEFAULT CHARSET=utf8;

UPDATE Product SET `name`="Seasonal subscription", `description`="April 1 - November 1 seasonal subscription to NAUTIC-ON to support transmission of data from your boat to NAUTIC-ON.", `unitPrice`=99.00
WHERE `name`= "6 month Seasonal subscription";
UPDATE Product SET `name`="1 year subscription", `description`="A 1 year subscription to NAUTIC-ON to support transmission of data from your boat to NAUTIC-ON."
WHERE `name`="1 year subscription";
